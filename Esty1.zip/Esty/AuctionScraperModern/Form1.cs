﻿using GoogleSearch;
using HtmlAgilityPack;
using MetroFramework;
using MetroFramework.Forms;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace AuctionScraperModern
{
    public partial class Form1 : MetroForm
    {
        public static List<MusicEvent> _MusicEventList = new List<MusicEvent>();

        public static HtmlWeb web = new HtmlWeb();
        public static DataTable dt = new DataTable();
        public static int number = 0;
        public static string[] emailsAll = { };
        public Form1()
        {
            InitializeComponent();           
            etsy();           
        }
        public void etsy()
        {
            List<etsyclss> _objList = new List<etsyclss>();
            try
            {
                
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                HtmlWeb web = new HtmlWeb();
                File.AppendAllText(@"..\etsy2.txt", "EtsySearchTerm	EtsyShop	EtsyShopURL	ofSales	ofReviews	ofItems	FacebookURL	TwitterURL	PinterestURL	InstagramURL	Website	Blog	Email	FacebookMessengerHandle	FirstName	LastName	Gender	BornOn	JoinedDate	City	State	Country" + Environment.NewLine);
                int fff = 0;
                for (int q = 1; q < 1000000; q++)
                {
                    try
                    {
                        var document = web.Load(@"https://www.etsy.com/in-en/search?q=printable+wall+art&ref=pagination&as_prefix=printable+wall+art&page=" + q);
                        HtmlNodeCollection MainCollection = document.DocumentNode.SelectNodes(".//a[contains(@class,'display-inline-block listing-link') or contains(@class,'block-grid-xs-2 block-grid-xl-4 hide-lg block-grid-no-whitespace float-clear pb-xs-1-5')]");

                        for (int j = 0; j < MainCollection.Count; j++)
                        {
                            try
                            {
                                etsyclss _obj = new etsyclss();                               

                                _obj.EtsySearchTerm = "printable wall art";
                                string item = MainCollection[j].Attributes["href"].Value;
                                var document2 = web.Load(item);
                                HtmlNodeCollection MainCollection2 = document2.DocumentNode.SelectNodes(".//a[@class='text-link-no-underline text-gray-lightest']");
                                try
                                {
                                    if (MainCollection2 == null)
                                    {
                                        MainCollection2 = document2.DocumentNode.SelectNodes(".//div[@class='shop-name']");
                                        if (MainCollection2 == null)
                                        {
                                            MainCollection2 = document2.DocumentNode.SelectNodes(".//div[@class='text-headline-smaller b mb-xs-1']");
                                            _obj.EtsyShopURL = MainCollection2[0].SelectSingleNode(".//a").Attributes["href"].Value;
                                        }
                                        else
                                        {
                                            _obj.EtsyShopURL = MainCollection2[0].SelectSingleNode(".//a").Attributes["href"].Value;
                                        }
                                    }
                                    else
                                    {
                                        _obj.EtsyShopURL = MainCollection2[0].Attributes["href"].Value;
                                    }
                                }
                                catch (Exception)
                                {
                                    continue;
                                }
                                int index = _obj.EtsyShopURL.IndexOf("?");
                                if (index > 0)
                                    _obj.EtsyShopURL = _obj.EtsyShopURL.Substring(0, index);
                                string value1 = File.ReadAllText(@"..\alllinks.txt");
                                if (value1.Contains(_obj.EtsyShopURL))
                                {
                                    continue;
                                }
                                fff++;
                                File.AppendAllText(@"..\count2.txt", fff + Environment.NewLine);
                                var documentShop = web.Load(_obj.EtsyShopURL);
                                HtmlNodeCollection MainCollectionshopname = documentShop.DocumentNode.SelectNodes(".//div[@class='shop-name-and-title-container mb-lg-2']/h1");
                                if (MainCollectionshopname != null)
                                {
                                    _obj.EtsyShop = Replace(MainCollectionshopname[0].InnerText.Trim());
                                }
                                else
                                {
                                    MainCollectionshopname = documentShop.DocumentNode.SelectNodes(".//div[@class='shop-name-and-title-container mb-xs-2']/h1");
                                    if (MainCollectionshopname != null)
                                    {
                                        _obj.EtsyShop = Replace(MainCollectionshopname[0].InnerText.Trim());
                                    }
                                    else
                                    {

                                    }
                                }
                                HtmlNodeCollection MainCollectionSales = documentShop.DocumentNode.SelectNodes(".//p[@class='trust-signal-row text-gray-lighter']/span");
                                if (MainCollectionSales != null)
                                {
                                    _obj.ofSales = Replace(MainCollectionSales[0].InnerText.Trim());
                                    if (_obj.ofSales == "")
                                    {
                                        MainCollectionSales = documentShop.DocumentNode.SelectNodes(".//a[@class='text-gray-lighter']");
                                        if (MainCollectionSales != null)
                                        {
                                            _obj.ofSales = Replace(MainCollectionSales[0].InnerText.Trim());
                                        }
                                    }
                                }
                                HtmlNodeCollection MainCollectionSales2 = documentShop.DocumentNode.SelectNodes(".//span[@class='mr-lg-2 pr-lg-2 br-lg-1']");
                                if (MainCollectionSales2 != null && _obj.ofSales == "")
                                {
                                    _obj.ofSales = Replace(MainCollectionSales2[0].InnerText.Trim());
                                }                                

                                HtmlNodeCollection MainCollectionReview = documentShop.DocumentNode.SelectNodes(".//span[@class='total-rating-count text-gray-lighter ml-lg-1']");
                                if (MainCollectionReview != null)
                                {
                                    _obj.ofReviews = MainCollectionReview[0].InnerText.Trim().Replace("(","");
                                    _obj.ofReviews = MainCollectionReview[0].InnerText.Trim().Replace(")", "");
                                }
                                HtmlNodeCollection MainCollectionItems = documentShop.DocumentNode.SelectNodes(".//a[@class='list-nav-item list-nav-item-has-badge is-selected']/span");
                                if (MainCollectionItems != null)
                                {
                                    _obj.ofItems = MainCollectionItems[0].InnerText.Trim();
                                }
                                HtmlNodeCollection MainCollectionFaceBook = documentShop.DocumentNode.SelectNodes(".//a[@title='Facebook']");
                                string FaceBook = string.Empty;
                                if (MainCollectionFaceBook != null)
                                {
                                    FaceBook = documentShop.DocumentNode.SelectSingleNode(".//a[@title='Facebook']").Attributes["href"].Value;
                                    _obj.Facebook = FaceBook;
                                    FaceBook = FaceBook.Replace("http://www.facebook.com/", "");
                                    FaceBook = FaceBook.Replace("?ref=hl", "");
                                    FaceBook = FaceBook.Replace("https://www.facebook.com/", "");
                                    FaceBook = FaceBook.Replace("http://facebook.com/", "");
                                    FaceBook = FaceBook.Replace("https://facebook.com/", "");
                                    FaceBook = FaceBook.Replace("https://fb.com/", "");
                                    FaceBook = FaceBook.Replace("http://fb.com/", "");
                                    FaceBook = FaceBook.Replace("http://www.fb.com/", "");
                                    FaceBook = FaceBook.Replace("https://www.fb.com/", "");
                                    FaceBook = FaceBook.Replace("/?ref=aymt_homepage_panel", "");
                                    FaceBook = FaceBook.Replace("?ref=sgm", "");
                                    FaceBook = FaceBook.Replace("/353635364664013", "");
                                    FaceBook = FaceBook.Replace("https://www.facebook.com/pages/", "");
                                    FaceBook = FaceBook.Replace("/?ref=bookmarks", "");
                                    FaceBook = FaceBook.Replace("/?pnref=lhc", "");
                                    FaceBook = FaceBook.Replace("?ref=br_rs&pnref=lhc", "");
                                    FaceBook = FaceBook.Replace("/timeline/", "");
                                    FaceBook = FaceBook.Replace("/?fref=ts", "");
                                    FaceBook = FaceBook.Replace("?ref=ts&fref=ts", "");
                                    FaceBook = FaceBook.Replace("?ref=br_rs", "");
                                    FaceBook = FaceBook.Replace("?ref=settings", "");
                                    FaceBook = FaceBook.Replace("/?ref=aymt_homepage_panel", "");
                                    FaceBook = FaceBook.Replace("http://www.facebook.com/#!/pages/", "");
                                    string[] fb = FaceBook.Split('/');
                                    FaceBook = fb[0];
                                    FaceBook = FaceBook.Replace("/", "");
                                }
                                else
                                {
                                    FaceBook = _obj.EtsyShop;
                                }
                                try
                                {
                                    var documentFaceBook = web.Load("https://www.facebook.com/pg/" + FaceBook + "/about/?ref=page_internal");
                                    HtmlNodeCollection MainCollectionEmail = documentFaceBook.DocumentNode.SelectNodes(".//div[@class='_4-u2 _3xaf _3-95 _4-u8']/div[@class='_5aj7 _3-8j']");
                                    if (MainCollectionEmail != null)
                                    {
                                        for (int m = 0; m < MainCollectionEmail.Count(); m++)
                                        {
                                            if ((MainCollectionEmail[m].InnerText.Contains("@") || MainCollectionEmail[m].InnerText.Contains("&#064;")) && MainCollectionEmail[m].InnerText.Contains("."))
                                            {
                                                if (_obj.EmailAddress=="")
                                                    _obj.EmailAddress = Replace(MainCollectionEmail[m].InnerText.Trim().Replace("&#064;", "@"));
                                            }
                                            else if (MainCollectionEmail[m].InnerText.Contains("@") || MainCollectionEmail[m].InnerText.Contains("&#064;"))
                                            {
                                                _obj.FacebookMessengerHandle = Replace(MainCollectionEmail[m].InnerText.Trim().Replace("&#064;", "@"));
                                            }
                                        }
                                    }
                                    if (_obj.EmailAddress == "")
                                    {
                                        try
                                        {
                                            HtmlNodeCollection MainCollectionEmailfbstring = documentFaceBook.DocumentNode.SelectNodes(".//div[@class='_4-u2 _3-98 _4-u8']");
                                            if (MainCollectionEmailfbstring != null)
                                            {
                                                string fbstring = MainCollectionEmailfbstring[0].InnerText;
                                                string[] lines = System.IO.File.ReadAllLines(@"..\domain.txt");
                                                if (fbstring.Contains("@"))
                                                {
                                                    foreach (string line in lines)
                                                    {
                                                        if (fbstring.Contains(line))
                                                        {
                                                            int toatl = line.Count();
                                                            int st = 1;
                                                            int en = fbstring.IndexOf(line, st);
                                                            string rt = fbstring.Substring(st, toatl + +en - st).Replace("\n", "");
                                                            st = rt.LastIndexOf(" ") + 1;
                                                            en = rt.IndexOf(line, st);
                                                            _obj.EmailAddress = rt.Substring(st, toatl + +en - st).Replace("\n", "");

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {

                                            throw;
                                        }
                                    }
                                    HtmlNodeCollection MainCollectionmsg = documentFaceBook.DocumentNode.SelectNodes(".//div[@class='_4-u2 _3xaf _3-95 _4-u8']/div[@class='_5aj7 _3-8j _20ud']");
                                    if (MainCollectionmsg != null)
                                    {
                                        for (int m = 0; m < MainCollectionmsg.Count(); m++)
                                        {
                                            if (MainCollectionmsg[m].InnerText.Contains("@") || MainCollectionmsg[m].InnerText.Contains("&#064;"))
                                            {
                                                _obj.FacebookMessengerHandle = MainCollectionmsg[m].InnerText.Trim().Replace("&#064;", "@");
                                                _obj.FacebookMessengerHandle = Replace(_obj.FacebookMessengerHandle.Replace("સંદેશ મોકલો", ""));
                                            }
                                        }
                                    }
                                }
                                catch (Exception) { }
                                finally { }

                                HtmlNodeCollection MainCollectionWebsite = documentShop.DocumentNode.SelectNodes(".//a[@title='Website']");
                                if (MainCollectionWebsite != null)
                                {
                                    _obj.Website = Replace(documentShop.DocumentNode.SelectSingleNode(".//a[@title='Website']").Attributes["href"].Value);
                                }
                                HtmlNodeCollection MainCollectionInsta = documentShop.DocumentNode.SelectNodes(".//a[@title='Instagram']");
                                if (MainCollectionInsta != null)
                                {
                                    _obj.Instagram = documentShop.DocumentNode.SelectSingleNode(".//a[@title='Instagram']").Attributes["href"].Value;

                                    if (_obj.Instagram != null && _obj.EmailAddress == "")
                                    {
                                        try
                                        {
                                            _obj.Instagram = _obj.Instagram.Replace("http://www.instagram.com/", "");
                                            _obj.Instagram = Replace(_obj.Instagram.Replace("https://www.instagram.com/", ""));
                                            WebClient w = new WebClient();
                                            string instaLink = "https://www.instagram.com/" + _obj.Instagram + "/?__a=1";
                                            string s = w.DownloadString(instaLink);
                                            RootObject22 _RootObject = JsonConvert.DeserializeObject<RootObject22>(s);

                                            string InstagramURLstring = _RootObject.graphql.user.biography.ToString().Replace("\n", "");
                                            string[] lines = System.IO.File.ReadAllLines(@"..\domain.txt");
                                            if (InstagramURLstring.Contains("@"))
                                            {
                                                foreach (string line in lines)
                                                {
                                                    if (InstagramURLstring.Contains(line))
                                                    {
                                                        int toatl = line.Count();
                                                        int st = 1;
                                                        int en = InstagramURLstring.IndexOf(line, st);
                                                        string rt = InstagramURLstring.Substring(st, toatl + +en - st).Replace("\n", "");
                                                        st = rt.LastIndexOf(" ") + 1;
                                                        en = rt.IndexOf(line, st);
                                                        _obj.EmailAddress = Replace(rt.Substring(st, toatl + +en - st).Replace("\n", ""));
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                        }
                                    }
                                }
                                HtmlNodeCollection MainCollectionPinterest = documentShop.DocumentNode.SelectNodes(".//a[@title='Pinterest']");
                                if (MainCollectionPinterest != null)
                                {
                                    _obj.Pinteres = Replace(documentShop.DocumentNode.SelectSingleNode(".//a[@title='Pinterest']").Attributes["href"].Value);
                                }
                                HtmlNodeCollection MainCollectionTwitter = documentShop.DocumentNode.SelectNodes(".//a[@title='Twitter']");
                                if (MainCollectionTwitter != null)
                                {
                                    _obj.Twitter = Replace(documentShop.DocumentNode.SelectSingleNode(".//a[@title='Twitter']").Attributes["href"].Value);
                                }

                                HtmlNodeCollection MainCollectionShowOwner = documentShop.DocumentNode.SelectNodes(".//div[@class='img-container']/a");
                                string ShopOwnerUrl = MainCollectionShowOwner[0].Attributes["href"].Value;

                                var documentShopOwner = web.Load("https://www.etsy.com" + ShopOwnerUrl);

                                HtmlNodeCollection MainCollectionUserName = documentShopOwner.DocumentNode.SelectNodes(".//div[@class='col-xs-4 col-xl-3']/h1");
                                if (MainCollectionUserName != null)
                                {
                                    _obj.FirstName = Replace(MainCollectionUserName[0].InnerText.Trim());
                                }
                                HtmlNodeCollection MainCollectionLocation = documentShopOwner.DocumentNode.SelectNodes(".//span[@class='shop-location mr-xs-2 pr-xs-2']");
                                if (MainCollectionLocation != null)
                                {
                                    string Location = MainCollectionLocation[0].InnerText.Trim();
                                    string[] allloc = Location.Split(',');
                                    _obj.City = allloc[0];
                                    if (allloc.Count() > 1)
                                    {
                                        _obj.State = allloc[1];
                                    }
                                    if (allloc.Count() > 2)
                                    {
                                        _obj.Country = allloc[2];
                                    }
                                }

                                HtmlNodeCollection MainCollectionJoined = documentShopOwner.DocumentNode.SelectNodes(".//p[@class='text-gray-lightest pt-xs-2 text-smaller']/span");
                                if (MainCollectionUserName != null)
                                {
                                    _obj.JoinedDate = Replace(MainCollectionJoined[0].InnerText.Trim().Replace("Joined&nbsp;", ""));
                                }
                              
                                _objList.Add(_obj);
                                File.AppendAllText(@"..\alllinks.txt", _obj.EtsyShopURL + Environment.NewLine);
                            }
                            catch (Exception ex)
                            {

                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }

                }
                string pathDesktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string appPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                string filePath = appPath + @"\RealEstate.csv";
                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Close();
                }
                DataTable dt = ToDataTable(_objList);
                ToCSV(dt, filePath);
            }
            catch (Exception ex)
            {

            }
           
        }

        public class etsyclss
        {
            public string EmailAddress { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string EtsySearchTerm { get; set; }
            public string EtsyShop { get; set; }
            public string EtsyShopURL { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string Country { get; set; }
            public string Instagram { get; set; }
            public string Facebook { get; set; }
            public string FacebookMessengerHandle  { get; set; }
            public string Pinteres { get; set; }
            public string Website { get; set; }
            public string Twitter { get; set; }
            public string JoinedDate { get; set; }
            public string ofSales { get; set; }
            public string ofReviews { get; set; }
            public string ofItems { get; set; }

        }
        public static void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        value = Replace(value);
                        sw.Write("\"" + value + "\"");
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public void GoogleSearch()
        {
            try
            {


                string[] linessss = System.IO.File.ReadAllLines(@"E:\esty.txt");
                foreach (var itemdsa in linessss)
                {
                    string Email = "";
                    try
                    {
                        var documentFaceBook = web.Load("https://www.facebook.com/pg/" + itemdsa + "/about/?ref=page_internal");
                        HtmlNodeCollection MainCollectionEmail = documentFaceBook.DocumentNode.SelectNodes(".//div[@class='_4-u2 _3xaf _3-95 _4-u8']/div[@class='_5aj7 _3-8j']");
                        if (MainCollectionEmail != null)
                        {
                            for (int m = 0; m < MainCollectionEmail.Count(); m++)
                            {
                                if ((MainCollectionEmail[m].InnerText.Contains("@") || MainCollectionEmail[m].InnerText.Contains("&#064;")) && MainCollectionEmail[m].InnerText.Contains("."))
                                {
                                    Email = Replace(MainCollectionEmail[m].InnerText.Trim().Replace("&#064;", "@"));
                                    File.AppendAllText(@"E:\Result.txt", itemdsa + "###" + Email + Environment.NewLine);
                                }
                            }
                        }
                        if (Email == "")
                        {
                            try
                            {
                                HtmlNodeCollection MainCollectionEmailfbstring = documentFaceBook.DocumentNode.SelectNodes(".//div[@class='_4-u2 _3-98 _4-u8']");
                                if (MainCollectionEmailfbstring != null)
                                {
                                    string fbstring = MainCollectionEmailfbstring[0].InnerText;
                                    string[] lines = System.IO.File.ReadAllLines(@"C:\Tunis\BackUp\IMDBPages\domain.txt");
                                    if (fbstring.Contains("@"))
                                    {
                                        foreach (string line in lines)
                                        {
                                            if (fbstring.Contains(line))
                                            {
                                                int toatl = line.Count();
                                                int st = 1;
                                                int en = fbstring.IndexOf(line, st);
                                                string rt = fbstring.Substring(st, toatl + +en - st).Replace("\n", "");
                                                st = rt.LastIndexOf(" ") + 1;
                                                en = rt.IndexOf(line, st);
                                                Email = rt.Substring(st, toatl + +en - st).Replace("\n", "");
                                                File.AppendAllText(@"E:\Result.txt", itemdsa + "###" + Email + Environment.NewLine);
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                continue;
                            }
                        }


                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }








                //var result = new HtmlWeb().Load("http://www.google.com/search?q=test&num=100&dcr=0&start=200&sa=N");
                //var nodes = result.DocumentNode.SelectNodes("//html//body//h3[@class='r']/a");
                //foreach (var item in nodes)
                //{
                //    string url = item.Attributes["href"].Value.Replace("/url?q=","");

                //    int resultIndex = url.IndexOf("&amp;sa=");
                //    if (resultIndex != -1)
                //    {
                //        url = url.Substring(0, resultIndex);
                //        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\etsy.txt", "EtsySearchTerm	EtsyShop	EtsyShopURL	ofSales	ofReviews	ofItems	FacebookURL	TwitterURL	PinterestURL	InstagramURL	Website	Blog	Email	FacebookMessengerHandle	FirstName	LastName	Gender	BornOn	JoinedDate	City	State	Country" + Environment.NewLine);
                //   }               
            }
            catch (Exception ex)
            {

            }
        }


        public void comicspriceguides()
        {
            try
            {

                string responseData = string.Empty;
                CookieContainer cookies = new CookieContainer();
                responseData = GetFirstRespParams("https://whitepages.tufts.edu/searchresults.cgi", ref cookies);
                string postData = "type=+&search=john";
                string HostName = "whitepages.tufts.edu";
                responseData = GetDataWithParamsJson("https://whitepages.tufts.edu/searchresults.cgi", ref cookies, postData, HostName);
                HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
                htmlDocument.LoadHtml(responseData);
                HtmlNodeCollection tr = htmlDocument.DocumentNode.SelectNodes("//table[@class='responsive-table']/tbody/tr/td/a");
                for (int j = 0; j < tr.Count; j++)
                {
                    try
                    {
                        string item = "https://whitepages.tufts.edu/" + tr[j].Attributes["href"].Value;
                        var document2 = web.Load(item);
                        HtmlNodeCollection MainCollection2 = document2.DocumentNode.SelectNodes("//table[@class='responsive-table']/tr");
                        HtmlNodeCollection td1 = MainCollection2[0].SelectNodes(".//td");
                        string name = td1[1].InnerText;

                        HtmlNodeCollection td2 = MainCollection2[1].SelectNodes(".//td");
                        string Role = td2[1].InnerText;

                        HtmlNodeCollection td3 = MainCollection2[2].SelectNodes(".//td");
                        string Department = td3[1].InnerText;

                        HtmlNodeCollection td4 = MainCollection2[5].SelectNodes(".//td");
                        string Email = td4[1].InnerText.Replace("&#", "");
                        string Emails = "";
                        string[] e = Email.Split(';');
                        for (int r = 0; r < e.Count(); r++)
                        {
                            int m = Convert.ToInt32(e[r]);
                            char character = (char)m;
                            Emails = Emails + character.ToString();
                        }
                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\etsy2.txt", "Name " + Environment.NewLine);
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        public void comicspriceguide()
        {
            try
            {
                List<ComicBook> _ComicBook = new List<ComicBook>();
                string ASIN = txtFirstName.Text;
                string responseData = string.Empty;
                CookieContainer cookies = new CookieContainer();
                responseData = GetFirstRespParams("https://comicspriceguide.com", ref cookies);
                string hs = ExtractViewState(responseData, "__RequestVerificationToken");
                string postData = "info%5Bun%5D=sorry1&info%5Bpw%5D=sorry123!&info%5Brm%5D=false&__RequestVerificationToken=" + hs;
                string HostName = "comicspriceguide.com";
                responseData = GetDataWithParamsJson("https://comicspriceguide.com/Account/popLogin", ref cookies, postData, HostName);
                responseData = GetFirstRespParams("https://comicspriceguide.com", ref cookies);
                responseData = GetFirstRespParams("https://comicspriceguide.com/publishers", ref cookies);

                hs = ExtractViewState(responseData, "__RequestVerificationToken");
                string uid = ExtractViewState(responseData, "hdnUIDs");

                string sec = ExtractViewState(responseData, "hdnSECs");

                postData = "filter%5Bpage%5D=1&filter%5Bper_page%5D=100&filter%5Bdirection%5D=asc&filter%5BfilterBy%5D=&filter%5BsearchBy%5D=&filter%5BsearchType%5D=anywords&filter%5Bletter%5D=%23&info%5Btext%5D=&info%5Buid%5D=" + uid +
                    "&info%5Bsec%5D=" + sec + "&__RequestVerificationToken=" + hs;

                responseData = GetDataWithParamsJson("https://comicspriceguide.com/Publisher/publishersReturn", ref cookies, postData, HostName);
                RootObject tmp = JsonConvert.DeserializeObject<RootObject>(responseData);

                string[] lines = File.ReadAllLines(@"C:\Tunis\BackUp\IMDBPages\3.txt");
                foreach (string line in lines)
                {
                    try
                    {
                        responseData = GetFirstRespParams("https://comicspriceguide.com/publishers/" + line, ref cookies);

                        hs = ExtractViewState(responseData, "__RequestVerificationToken");

                        uid = ExtractViewState(responseData, "hdnUIDs");
                        sec = ExtractViewState(responseData, "hdnSECs");

                        string pid = ExtractViewState(responseData, "hdnPID");
                        //writeLog(item.name + "	" + item.titleCount );
                        string postnew = "filter%5Bpage%5D=1&filter%5Bper_page%5D=100&filter%5Bdirection%5D=asc&filter%5BfilterBy%5D=all&filter%5BsearchBy%5D=&filter%5BsearchTabs%5D=searches&info%5Bpid%5D=" + pid +
                            "&info%5Buid%5D=" + uid + "&info%5Bsec%5D=" + sec + "&__RequestVerificationToken=" + hs;
                        responseData = GetDataWithParamsJson("https://comicspriceguide.com/Publisher/titlesReturn", ref cookies, postnew, HostName);
                        RootObject2 tmp2 = JsonConvert.DeserializeObject<RootObject2>(responseData);
                        foreach (var item in tmp2.items)
                        {

                            try
                            {
                                responseData = GetFirstRespParams("https://comicspriceguide.com/titles/" + item.nameSEO + "/" + item.idENC, ref cookies);
                                hs = ExtractViewState(responseData, "__RequestVerificationToken");


                                uid = ExtractViewState(responseData, "hdnUIDs");
                                sec = ExtractViewState(responseData, "hdnSECs");

                                pid = ExtractViewState(responseData, "hdnPID");
                                string tid = ExtractViewState(responseData, "hdnTID");

                                string postnew2 = "filter%5Bpage%5D=1&filter%5Bper_page%5D=100&filter%5Bdirection%5D=asc&filter%5BfilterBy%5D=&filter%5BsearchBy%5D=&filter%5BshowVariants%5D=true&filter%5BsearchTabs%5D=priceguide" +
                                    "&info%5Btid%5D=" + tid + "&info%5Bpid%5D=" + pid + "&info%5Buid%5D=" + uid + "&info%5Bsec%5D=" + sec + "&__RequestVerificationToken=" + hs;
                                responseData = GetDataWithParamsJson("https://comicspriceguide.com/Title/titleReturn", ref cookies, postnew2, HostName);
                                Comic.RootObject tmp3 = JsonConvert.DeserializeObject<Comic.RootObject>(responseData);
                                if (tmp3.pages != null)
                                {
                                    for (int i = 1; i < tmp3.pages + 1; i++)
                                    {
                                        try
                                        {
                                            postnew2 = "filter%5Bpage%5D=" + i + "&filter%5Bper_page%5D=100&filter%5Bdirection%5D=asc&filter%5BfilterBy%5D=&filter%5BsearchBy%5D=&filter%5BshowVariants%5D=true&filter%5BsearchTabs%5D=priceguide" +
                                    "&info%5Btid%5D=" + tid + "&info%5Bpid%5D=" + pid + "&info%5Buid%5D=" + uid + "&info%5Bsec%5D=" + sec + "&__RequestVerificationToken=" + hs;
                                            responseData = GetDataWithParamsJson("https://comicspriceguide.com/Title/titleReturn", ref cookies, postnew2, HostName);
                                            Comic.RootObject tmp4 = JsonConvert.DeserializeObject<Comic.RootObject>(responseData);
                                            if (tmp4.items != null)
                                            {
                                                foreach (var itemfinal in tmp4.items)
                                                {
                                                    try
                                                    {
                                                        responseData = GetFirstRespParams("https://comicspriceguide.com/titles/" + itemfinal.title.nameSEO + "/" + itemfinal.number + "/" + itemfinal.idENC, ref cookies);

                                                        ComicBook _objComicBook = new ComicBook();
                                                        _objComicBook.URLofpageImage = (itemfinal.coverScans.lrgScan != null) ? itemfinal.coverScans.lrgScan : itemfinal.coverScans.medScan;

                                                        _objComicBook.URLofpage = "https://comicspriceguide.com/titles/" + itemfinal.title.nameSEO + "/" + itemfinal.number + "/" + itemfinal.idENC;
                                                        _objComicBook.Publisher = itemfinal.title.publisher.name;
                                                        _objComicBook.Volume = itemfinal.title.volume;
                                                        _objComicBook.ComicAge = itemfinal.age.name;


                                                        _objComicBook.PublishDate2 = itemfinal.dates.monthName + " " + itemfinal.dates.year;

                                                        HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
                                                        htmlDocument.LoadHtml(responseData);
                                                        HtmlNodeCollection MainCollectionPublishDate = htmlDocument.DocumentNode.SelectNodes(".//span[@id='lblYears']");
                                                        if (MainCollectionPublishDate != null)
                                                            _objComicBook.PublishDate = MainCollectionPublishDate[0].InnerText;
                                                        HtmlNodeCollection MainCollectionTitle = htmlDocument.DocumentNode.SelectNodes(".//div[@class='card__body clearfix']/header/h2[@class='h--boom p-b-0']");
                                                        _objComicBook.Title = MainCollectionTitle[0].InnerText;
                                                        HtmlNodeCollection MainCollection1 = htmlDocument.DocumentNode.SelectNodes(".//div[@class='clearfix']/div[@class='col-sm-3 m-b-10 text-center']/span");
                                                        if (MainCollection1 != null && MainCollection1.Count() > 2)
                                                        {
                                                            // _objComicBook.StoryArc = MainCollection1[3].InnerText.Replace("Add", "").Trim();
                                                            _objComicBook.CoverPrice = MainCollection1[2].InnerText.Replace("Add", "").Trim();
                                                            _objComicBook.ISBN10 = "";
                                                            _objComicBook.ISBN13 = "";

                                                        }
                                                        HtmlNodeCollection MainCollection1upc = htmlDocument.DocumentNode.SelectNodes(".//div[@class='clearfix']/div[@class='col-sm-3  m-b-10  text-center']/span");

                                                        if (MainCollection1upc != null)
                                                        {

                                                            _objComicBook.UPC = MainCollection1upc[0].InnerText.Replace("Add", "").Trim();


                                                        }
                                                        HtmlNodeCollection MainCollection2 = htmlDocument.DocumentNode.SelectNodes(".//div[@class='col-lg-10 col-sm-10 fkCreator']");
                                                        if (MainCollection2 != null)
                                                        {
                                                            _objComicBook.Writers = MainCollection2[0].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.Artists = MainCollection2[1].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.CoverArt = MainCollection2[2].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.Inkers = MainCollection2[3].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.Letterers = MainCollection2[4].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.Colorists = MainCollection2[5].InnerText.Replace("\r\n", " ").Trim();
                                                            _objComicBook.Editors = MainCollection2[6].InnerText.Replace("\r\n", " ").Trim();
                                                        }
                                                        HtmlNodeCollection USStory = htmlDocument.DocumentNode.SelectNodes(".//div[@id='dvStoryList']/div[@class='tab-content']/div");
                                                        if (USStory != null)
                                                        {
                                                            for (int t = 0; t < USStory.Count; t++)
                                                            {
                                                                string nnn = Replace(USStory[t].InnerText.Trim());
                                                                if (t == 0)
                                                                    _objComicBook.Stories1 = nnn;
                                                                if (t == 1)
                                                                    _objComicBook.Stories2 = nnn;
                                                                if (t == 2)
                                                                    _objComicBook.Stories3 = nnn;
                                                                if (t == 3)
                                                                    _objComicBook.Stories4 = nnn;
                                                                if (t == 4)
                                                                    _objComicBook.Stories5 = nnn;
                                                                if (t == 5)
                                                                    _objComicBook.Stories6 = nnn;
                                                                if (t == 6)
                                                                    _objComicBook.Stories7 = nnn;
                                                                if (t == 7)
                                                                    _objComicBook.Stories8 = nnn;
                                                                if (t == 8)
                                                                    _objComicBook.Stories9 = nnn;
                                                                if (t == 9)
                                                                    _objComicBook.Stories10 = nnn;
                                                                if (t == 10)
                                                                    _objComicBook.Stories11 = nnn;
                                                                if (t == 11)
                                                                    _objComicBook.Stories12 = nnn;
                                                                if (t == 12)
                                                                    _objComicBook.Stories13 = nnn;
                                                                if (t == 13)
                                                                    _objComicBook.Stories14 = nnn;
                                                                if (t == 14)
                                                                    _objComicBook.Stories15 = nnn;
                                                            }
                                                        }

                                                        HtmlNodeCollection facts = htmlDocument.DocumentNode.SelectNodes(".//div[@id='dvFactList']");
                                                        if (facts != null)
                                                        {
                                                            _objComicBook.Facts = Replace(facts[0].InnerText.Trim().Replace("Issue Facts", ""));
                                                            _objComicBook.Facts = _objComicBook.Facts.Replace(" Add", "");
                                                        }
                                                        _ComicBook.Add(_objComicBook);

                                                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\Comic\3.txt", _objComicBook.Title + Environment.NewLine);
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\Error.txt", ex.Message + Environment.NewLine);
                                            continue;
                                        }

                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\Error.txt", ex.Message + Environment.NewLine);
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\Error.txt", ex.Message + Environment.NewLine);
                        continue;
                    }

                }
                string appPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\ExportFile";
                bool exists = System.IO.Directory.Exists(appPath);
                if (!exists)
                {
                    System.IO.Directory.CreateDirectory(appPath);
                }
                string filePath = appPath + @"Marvel.csv";
                dt = ToDataTable(_ComicBook);
                ToCSV(dt, filePath);
            }
            catch (Exception ex)
            {
                File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\Error.txt", ex.Message + Environment.NewLine);
            }
        }



        public void tradeindia()
        {
            HtmlWeb web = new HtmlWeb();

            List<string> _lst = new List<string>();
            //_lst.Add("https://www.tradeindia.com/Seller/Consumer-Electronics/");
            //_lst.Add("https://www.tradeindia.com/Seller/Electronics-Electrical-Supplies/");
            //_lst.Add("https://www.tradeindia.com/Seller/Energy-Power/");
            //_lst.Add("https://www.tradeindia.com/Seller/Environment-Pollution/");
            //_lst.Add("https://www.tradeindia.com/Seller/Food-Beverage/");
            //_lst.Add("https://www.tradeindia.com/Seller/Furniture/");
            //_lst.Add("https://www.tradeindia.com/Seller/Gifts-Crafts/");
            //_lst.Add("https://www.tradeindia.com/Seller/Health-Beauty/");
            //_lst.Add("https://www.tradeindia.com/Seller/Home-Supplies/");
            //_lst.Add("https://www.tradeindia.com/Seller/Home-Textiles-Furnishings/");
            //_lst.Add("https://www.tradeindia.com/Seller/Hospital-Medical-Supplies/");
            //_lst.Add("https://www.tradeindia.com/Seller/Hotel-Supplies-Equipment/");
            //_lst.Add("https://www.tradeindia.com/Seller/Jewelry-Gemstones/");
            //_lst.Add("https://www.tradeindia.com/Seller/Leather-Leather-Products/");
            //_lst.Add("https://www.tradeindia.com/Seller/Machinery/");
            _lst.Add("https://www.tradeindia.com/Seller/Merchant-Exporters/");
            _lst.Add("https://www.tradeindia.com/Seller/Merchant-Importers/");
            _lst.Add("https://www.tradeindia.com/Seller/Mineral-Metals/");
            _lst.Add("https://www.tradeindia.com/Seller/Office-School-Supplies/");
            _lst.Add("https://www.tradeindia.com/Seller/Packaging-Paper/");
            _lst.Add("https://www.tradeindia.com/Seller/Pipes-Tubes-Fittings/");
            _lst.Add("https://www.tradeindia.com/Seller/Plastics-Products/");
            _lst.Add("https://www.tradeindia.com/Seller/Printing-Publishing/");
            _lst.Add("https://www.tradeindia.com/Seller/Scientific-Laboratory-Instruments/");
            _lst.Add("https://www.tradeindia.com/Seller/Security-Protection/");
            _lst.Add("https://www.tradeindia.com/Seller/Sports-Entertainment/");
            _lst.Add("https://www.tradeindia.com/Seller/Telecommunications/");
            _lst.Add("https://www.tradeindia.com/Seller/Textiles-Fabrics/");
            _lst.Add("https://www.tradeindia.com/Seller/Toys/");
            _lst.Add("https://www.tradeindia.com/Seller/Transportation/");
            _lst.Add("https://www.tradeindia.com/Seller/Others/");

            foreach (var iurl in _lst)
            {
                string nn = iurl.Replace("https://www.tradeindia.com/Seller/", "");
                nn = nn.Replace("/", "");
                nn = nn.Replace("-", "");
                File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\" + nn + ".txt", "ProductName\tCompany\tAddress\tphonedetails\tContact Person" + Environment.NewLine);
                var document = web.Load(iurl);
                HtmlNodeCollection MainCollection = document.DocumentNode.SelectNodes(".//div[@class='divTable']/div[@class='divTableRow']/div[@class='divTableCell categories-item']/div[@class='catImg']");
                if (MainCollection == null)
                {
                    continue;
                }
                for (int j = 0; j < MainCollection.Count; j++)
                {
                    try
                    {
                        string item = MainCollection[j].SelectSingleNode(".//a").Attributes["href"].Value;
                        var document2 = web.Load(@"https://www.tradeindia.com" + item);
                        HtmlNodeCollection MainCollection2 = document2.DocumentNode.SelectNodes(".//div[@class='divTable sm-product-view']/div/div");
                        for (int i = 0; i < MainCollection2.Count; i++)
                        {
                            try
                            {
                                string item2 = MainCollection2[i].SelectSingleNode(".//a").Attributes["href"].Value;
                                var document3 = web.Load(@"https://www.tradeindia.com" + item2);
                                HtmlNodeCollection MainCollection3 = document3.DocumentNode.SelectNodes(".//ul[@id='responsive-grid']/li");
                                for (int k = 0; k < MainCollection3.Count; k++)
                                {
                                    try
                                    {
                                        HtmlNodeCollection ProductNameCollection = MainCollection3[k].SelectNodes(".//span[@class='prod-title']");
                                        string ProductName = Replace(ProductNameCollection[0].InnerText.Trim());
                                        string Company = "";
                                        HtmlNodeCollection CompanyCollection = MainCollection3[k].SelectNodes(".//div[@class='heading']/a");
                                        if (CompanyCollection != null)
                                        {
                                            Company = Replace(CompanyCollection[0].InnerText.Trim());
                                        }
                                        string Address = "";
                                        HtmlNodeCollection AddressCollection = MainCollection3[k].SelectNodes(".//span[@class='add-full tooltip-bottom bold']");
                                        if (AddressCollection != null)
                                        {
                                            Address = Replace(AddressCollection[0].Attributes["data-tooltip"].Value.Trim());
                                        }
                                        string phonedetails = "";
                                        string User = "";
                                        HtmlNodeCollection PhoneCollection = MainCollection3[k].SelectNodes(".//span[@class='mob']");
                                        if (PhoneCollection != null)
                                        {
                                            phonedetails = Replace(PhoneCollection[0].InnerText.Trim());
                                        }
                                        else
                                        {
                                            PhoneCollection = MainCollection3[k].SelectNodes(".//div[@class='c-details-search margin-15']/div/div/a");
                                            if (PhoneCollection != null)
                                            {
                                                string Phone = Replace(PhoneCollection[0].Attributes["onclick"].Value.Trim());

                                                int startDriverss = Phone.IndexOf("default_mobile") + 17;
                                                int endDriverss = Phone.IndexOf("'  'designation' ", startDriverss);
                                                if (startDriverss != 16 && endDriverss != -1)
                                                {
                                                    phonedetails = Replace(Phone.Substring(startDriverss, endDriverss - startDriverss).Trim().Replace("\t\t", ""));
                                                }

                                                int startDriverss1 = Phone.IndexOf("username' : ") + 13;
                                                int endDriverss1 = Phone.IndexOf("'  'default_mobile' :", startDriverss1);
                                                if (startDriverss != 12 && endDriverss != -1)
                                                {
                                                    User = Replace(Phone.Substring(startDriverss1, endDriverss1 - startDriverss1).Trim().Replace("\t\t", ""));
                                                }
                                            }
                                        }
                                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\" + nn + ".txt", ProductName + "\t" + Company + "\t" + Address + "\t" + phonedetails + "\t" + User + Environment.NewLine);
                                    }
                                    catch (Exception ex)
                                    {
                                        continue;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
            }

        }
        public void fmcsa()
        {
            try
            {
                List<string> _list = new List<string>();
                // _list.Add("TRUCKING"); _list.Add("llc"); _list.Add("ltd"); _list.Add("COMPANY"); _list.Add("INC"); _list.Add("TRANSPORT"); _list.Add("and");
                _list.Add("TRUCK"); _list.Add("SALES"); _list.Add("SERVICE"); _list.Add("CORP");
                //  File.AppendAllText(@"E:\SampleDatanew2.txt", "DOT\tLegalName\tDBAName\tAddress\tCity\tState\tZIPCode\tPhone\tFAX\tEmail\tTotalTrucks\tTotalDrivers" + Environment.NewLine);
                foreach (var c in _list)
                {
                    int i = 0;
                    for (; ; )
                    {
                        i++;
                        try
                        {
                            var document = web.Load("https://ai.fmcsa.dot.gov/SMS/Search/SimpleSearchResults.aspx?Name=" + c + "&USState=TX&LocationType=US&Page=" + i + "&Sort=NoSort&Submit=JS");
                            HtmlNodeCollection MainCollection = document.DocumentNode.SelectNodes("//tbody[@class='dataBody']/tr");
                            if (MainCollection != null)
                            {
                                for (int j = 0; j < MainCollection.Count; j++)
                                {
                                    try
                                    {
                                        HtmlNodeCollection td = MainCollection[j].SelectNodes(".//td");
                                        if (td != null && td.Count() == 15)
                                        {
                                            string USDOT = Replace(td[0].InnerText.Trim());
                                            string LegalName = Replace(td[1].InnerText.Trim());
                                            string DBAName = Replace(td[2].InnerText.Trim());
                                            string State = Replace(td[6].InnerText.Trim());
                                            string City = Replace(td[8].InnerText.Trim());
                                            string TotalTrucks = Replace(td[12].InnerText.Trim());
                                            var DOT = web.Load("https://ai.fmcsa.dot.gov/SMS/Carrier/" + USDOT + "/CarrierRegistration.aspx");
                                            HtmlNodeCollection DOTCollection = DOT.DocumentNode.SelectNodes("//div[@id='regBox']/ul");
                                            string resultDrivers = "";
                                            string DefaultDriverss = DOTCollection[1].InnerText;
                                            int startDriverss = DefaultDriverss.IndexOf("Drivers:") + 8;
                                            int endDriverss = DefaultDriverss.IndexOf("Carrier Operation:", startDriverss);
                                            if (startDriverss != 7 && endDriverss != -1)
                                            {
                                                resultDrivers = Replace(DefaultDriverss.Substring(startDriverss, endDriverss - startDriverss).Trim().Replace("\t\t", ""));
                                            }

                                            string Fax = "";
                                            string DefaultteleFax = DOTCollection[0].InnerText;
                                            int startteleFax = DefaultteleFax.IndexOf("Fax:") + 4;
                                            int endteleFax = DefaultteleFax.IndexOf("Email:", startteleFax);
                                            if (startDriverss != 3 && endDriverss != -1)
                                            {
                                                Fax = DefaultteleFax.Substring(startteleFax, endteleFax - startteleFax).Trim().Replace("\t\t", "");
                                            }
                                            string Phone = "";
                                            string Defaulttelephone = DOTCollection[0].InnerText;
                                            int starttelephone = Defaulttelephone.IndexOf("Telephone:") + 10;
                                            int endtelephone = Defaulttelephone.IndexOf("Fax:", starttelephone);
                                            if (startDriverss != 9 && endDriverss != -1)
                                            {
                                                Phone = Defaulttelephone.Substring(starttelephone, endtelephone - starttelephone).Trim().Replace("\t\t", "");
                                            }
                                            string Email = "";
                                            string DefaultTrucks = DOTCollection[0].InnerText;
                                            int startTrucks = DefaultTrucks.IndexOf("Email:") + 6;
                                            int endTrucks = startTrucks + 200;
                                            if (startTrucks != 11 && endTrucks != -1)
                                            {
                                                Email = Replace1(DefaultTrucks.Substring(startTrucks, endTrucks - startTrucks).Trim().Replace("\t\t", ""));
                                            }

                                            string addressLocality = ""; string postalCode = "";
                                            string DefaultaddressLocality = DOTCollection[0].InnerText;
                                            int startaddressLocality = DefaultaddressLocality.IndexOf("Address:") + 8;
                                            int endaddressLocality = DefaultaddressLocality.IndexOf("Telephone:", startaddressLocality);
                                            if (startaddressLocality != 7 && endaddressLocality != -1)
                                            {
                                                addressLocality = DefaultaddressLocality.Substring(startaddressLocality, endaddressLocality - startaddressLocality).Trim().Replace("</div><div>", " ");
                                                addressLocality = addressLocality.Replace(",", " ");
                                                addressLocality = addressLocality.Replace("TX", ",");
                                                string[] tokens = addressLocality.Split(',');
                                                addressLocality = Replace(tokens[0].Replace(",", "").Trim());
                                                postalCode = Replace(tokens[1].Trim().Replace("TX", "").Trim());
                                            }


                                            File.AppendAllText(@"E:\SampleDatanew2.txt", USDOT + "\t" + LegalName + "\t" + DBAName + "\t" + addressLocality + "\t" + City + "\t" + State + "\t" + postalCode + "\t" + Phone + "\t" + Fax + "\t" + Email + "\t" + TotalTrucks + "\t" + resultDrivers + Environment.NewLine);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        continue;
                                    }
                                }
                            }
                            else
                            {
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public void freightconnect()
        {
            int tp = 0;
            try
            {

                var document = web.Load("https://www.freightconnect.com/usa-trucking-companies");
                HtmlNodeCollection LiNodeCollection = document.DocumentNode.SelectNodes("//div[@class='panel panel-default']/div[@class='panel-body']/a");
                for (int i = 0; i < LiNodeCollection.Count; i++)
                {
                    try
                    {
                        string collectionURL = "https://www.freightconnect.com" + LiNodeCollection[i].Attributes["href"].Value;
                        var maindoc = web.Load(collectionURL);
                        HtmlNodeCollection MainCollection = maindoc.DocumentNode.SelectNodes("//div[@class='panel panel-default']/div[@class='panel-body']/a");
                        for (int j = 0; j < MainCollection.Count; j++)
                        {
                            try
                            {
                                string collectionURL2 = "https://www.freightconnect.com" + MainCollection[j].Attributes["href"].Value;
                                var maindoc2 = web.Load(collectionURL2);

                                HtmlNodeCollection CollectionTitle = maindoc2.DocumentNode.SelectNodes("//div[@class='row motor-carrier-list']/div/div/div");
                                if (CollectionTitle != null)
                                {
                                    tp++;
                                    string NameCom = "";
                                    HtmlNodeCollection CollectionNameCom = CollectionTitle[0].SelectNodes(".//h3[@class='h4']");
                                    if (CollectionNameCom != null)
                                    {
                                        NameCom = Replace1(CollectionNameCom[0].InnerText.Trim());
                                    }
                                    string resultUSDOT = "";
                                    string DefaultUSDOT = CollectionTitle[0].InnerText;
                                    int startUSDOT = DefaultUSDOT.IndexOf("DOT#") + 4;
                                    int endUSDOT = DefaultUSDOT.IndexOf("Drivers:", startUSDOT);
                                    if (startUSDOT != 4 && endUSDOT != -1)
                                    {
                                        resultUSDOT = DefaultUSDOT.Substring(startUSDOT, endUSDOT - startUSDOT).Trim().Replace("\t\t", "");
                                        resultUSDOT = Replace1(resultUSDOT.Replace("&nbsp;", ""));
                                    }
                                    string resultDrivers = "";
                                    string DefaultDriverss = CollectionTitle[0].InnerText;
                                    int startDriverss = DefaultDriverss.IndexOf("Drivers:") + 8;
                                    int endDriverss = DefaultDriverss.IndexOf("Power Units", startDriverss);
                                    if (startDriverss != 7 && endDriverss != -1)
                                    {
                                        resultDrivers = Replace1(DefaultDriverss.Substring(startDriverss, endDriverss - startDriverss).Trim().Replace("\t\t", ""));
                                    }
                                    string resultTrucks = "";
                                    string DefaultTrucks = CollectionTitle[0].InnerHtml;
                                    int startTrucks = DefaultTrucks.IndexOf("Power Units:") + 12;
                                    int endTrucks = DefaultTrucks.IndexOf("</div><address><div>", startTrucks);
                                    if (startTrucks != 11 && endTrucks != -1)
                                    {
                                        resultTrucks = Replace1(DefaultTrucks.Substring(startTrucks, endTrucks - startTrucks).Trim().Replace("\t\t", ""));
                                    }

                                    string addressLocality = ""; string postalCode = "";
                                    string DefaultaddressLocality = CollectionTitle[0].InnerHtml;
                                    int startaddressLocality = DefaultaddressLocality.IndexOf("</div><address><div>") + 21;
                                    int endaddressLocality = DefaultaddressLocality.IndexOf("</div><div>Phone:", startaddressLocality);
                                    if (startaddressLocality != 20 && endaddressLocality != -1)
                                    {
                                        addressLocality = DefaultaddressLocality.Substring(startaddressLocality, endaddressLocality - startaddressLocality).Trim().Replace("</div><div>", " ");

                                        string[] tokens = addressLocality.Split(',');
                                        addressLocality = Replace1(tokens[0].Replace(",", "").Trim());
                                        postalCode = Replace1(tokens[1].Trim().Replace("TX", "").Trim());
                                    }
                                    string addressRegion = "TX";
                                    string telephone = "";
                                    string Defaulttelephone = CollectionTitle[0].InnerText;
                                    int starttelephone = Defaulttelephone.IndexOf("Phone:") + 6;
                                    int endtelephone = Defaulttelephone.IndexOf("Fax:", starttelephone);
                                    if (starttelephone != 5)
                                    {
                                        if (endtelephone == -1)
                                            endtelephone = Defaulttelephone.IndexOf("View Trucking Company", starttelephone);
                                        telephone = Defaulttelephone.Substring(starttelephone, endtelephone - starttelephone).Trim().Replace("\t\t", "");

                                    }


                                    File.AppendAllText(@"E:\hastag.txt", NameCom + "\t" + addressLocality + "\t" + addressRegion + "\t" + postalCode + "\t" + telephone + "\t" + resultTrucks + "\t" + resultDrivers + "\t" + resultUSDOT + "\t" + Environment.NewLine);
                                }
                                else
                                    continue;





                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.ToString() == "The operation has timed out")
                                    j--;
                                Thread.Sleep(1000);
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public class Amazon
        {
            public string ASIN { get; set; }
            public DateTime DateofReview { get; set; }
            public string SellerID { get; set; }
            public string ReviwerID { get; set; }
            public double ReviewRating { get; set; }
            public string RatingSummary { get; set; }
            public string TextoftheReview { get; set; }
            public bool Photo { get; set; }
            public bool Video { get; set; }

        }
        public static void Amazonss()
        {
            try
            {
                string ASIN = "B01GPCLFDC";
                List<Amazon> _AmazonList = new List<Amazon>();
                string responseData = string.Empty;
                CookieContainer cookies = new CookieContainer();
                responseData = GetFirstRespParams("https://www.amazon.com/", ref cookies);
                responseData = GetFirstRespParams("http://www.amazon.com/gp/customer-reviews/common/du/displayHistoPopAjax.html?&ASIN=" + ASIN, ref cookies);

                HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
                htmlDocument.LoadHtml(responseData);
                HtmlNodeCollection tr = htmlDocument.DocumentNode.SelectNodes("//div[@class='advice-quote-hist-seall']/a");
                string URI = tr[0].Attributes["href"].Value;
                int totalcount = Convert.ToInt32(Regex.Match(tr[0].InnerText.Replace(",", ""), @"\d+").Value);
                responseData = GetFirstRespParams(URI, ref cookies);
                htmlDocument.LoadHtml(responseData);
                HtmlNodeCollection profile1 = htmlDocument.DocumentNode.SelectNodes("//div[@class='a-row product-title']/h1/a");
                string profileurl2 = "https://www.amazon.com" + profile1[0].Attributes["href"].Value;
                responseData = GetFirstRespParams(profileurl2, ref cookies);
                htmlDocument.LoadHtml(responseData);
                HtmlNodeCollection profile3 = htmlDocument.DocumentNode.SelectNodes("//div[@id='merchant-info']/a");
                string sellerID = string.Empty;
                if (profile3 != null)
                {
                    string profileurl5 = "https://www.amazon.com" + profile3[0].Attributes["href"].Value;
                    sellerID = GetFirst(profileurl5, ref cookies);
                }
                else
                {
                    string profileurl5 = "https://www.amazon.com" + profile3[0].Attributes["href"].Value;
                }
                int totalPage = totalcount / 50;
                for (int i = 1; i < totalPage + 1; i++)
                {
                    try
                    {
                        string t = "cm_cr_getr_d_paging_btm_" + i + "?ie=UTF8&pageNumber=" + i + "&pageSize=50";
                        string URInew = URI.Replace("refhist_all?ie=UTF8&showViewpoints=1", t);
                        responseData = GetFirstRespParams(URInew, ref cookies);
                        htmlDocument.LoadHtml(responseData);
                        HtmlNodeCollection collection = htmlDocument.DocumentNode.SelectNodes("//div[@id='cm_cr-review_list']/div");
                        for (int j = 0; j < collection.Count() - 1; j++)
                        {
                            try
                            {
                                Amazon _amazon = new Amazon();
                                _amazon.ASIN = ASIN;
                                _amazon.SellerID = sellerID;
                                HtmlNodeCollection date = collection[j].SelectNodes(".//span[@data-hook='review-date']");
                                string datestr = date[0].InnerText.Replace("on", "");
                                _amazon.DateofReview = Convert.ToDateTime(datestr);

                                HtmlNodeCollection title = collection[j].SelectNodes(".//a[@data-hook='review-title']");
                                _amazon.RatingSummary = title[0].InnerText;

                                HtmlNodeCollection ReviewRating = collection[j].SelectNodes(".//i[@data-hook='review-star-rating']");
                                _amazon.ReviewRating = Convert.ToDouble(ReviewRating[0].InnerText.Replace("out of 5 stars", ""));

                                HtmlNodeCollection ReviwerID = collection[j].SelectNodes(".//a[@data-hook='review-author']");
                                _amazon.ReviwerID = "https://www.amazon.com" + ReviwerID[0].Attributes["href"].Value;

                                HtmlNodeCollection TextoftheReview = collection[j].SelectNodes(".//span[@data-hook='review-body']");
                                _amazon.TextoftheReview = TextoftheReview[0].InnerText;

                                HtmlNodeCollection Photo = collection[j].SelectNodes(".//div[@data-hook='review-image-tile-section']");
                                if (Photo != null)
                                    _amazon.Photo = true;
                                else
                                    _amazon.Photo = false;

                                HtmlNodeCollection Video = collection[j].SelectNodes(".//input[@class='video-url']");
                                if (Video != null)
                                    _amazon.Video = true;
                                else
                                    _amazon.Video = false;

                                _AmazonList.Add(_amazon);
                            }
                            catch (Exception ex)
                            {
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public void quicktransportsolutions()
        {
            try
            {
                File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", "USDOT ,NAME,COMPANY NAME,ADDRESS,CITY ,STATE ,ZIP,TRUCKS ,DRIVERS,PHONE," + Environment.NewLine);

                HtmlAgilityPack.HtmlDocument document = web.Load("https://www.quicktransportsolutions.com/carrier/texas/trucking-companies.php");

                HtmlNodeCollection LiNodeCollection = document.DocumentNode.SelectNodes("//table[@class='table table-condensed table-striped table-hover table-bordered']/tbody/tr/td/a");
                for (int i = 0; i < LiNodeCollection.Count; i++)
                {
                    try
                    {
                        string t = "";
                        if (LiNodeCollection[i].InnerText != "")
                        {
                            t = LiNodeCollection[i].Attributes["href"].Value;
                        }
                        else
                        {
                            continue;
                        }
                        string collectionURL = "https://www.quicktransportsolutions.com/carrier/texas/" + t;
                        var maindoc = web.Load(collectionURL);
                        HtmlNodeCollection MainCollection = maindoc.DocumentNode.SelectNodes(".//div[@class='panel-body']/div[@class='row clearfix']/div/div");
                        for (int j = 0; j < MainCollection.Count; j++)
                        {
                            try
                            {
                                string Title = "";
                                HtmlNodeCollection CollectionTitle = MainCollection[j].SelectNodes(".//div[@class='well well-sm']/div/b");
                                if (CollectionTitle != null && CollectionTitle.Count() > 1)
                                {
                                    Title = CollectionTitle[0].InnerText.Trim();
                                    if (Title.Contains("&nbsp;"))
                                    {
                                        Title = "";
                                    }

                                }
                                string NameCom = "";
                                HtmlNodeCollection CollectionNameCom = MainCollection[j].SelectNodes(".//span[@itemprop='name']/b");
                                if (CollectionNameCom != null)
                                {
                                    NameCom = CollectionNameCom[0].InnerText.Trim();
                                }
                                string streetAddress = "";
                                HtmlNodeCollection CollectionstreetAddress = MainCollection[j].SelectNodes(".//span[@itemprop='streetAddress']");
                                if (CollectionstreetAddress != null)
                                {
                                    streetAddress = Replace1(CollectionstreetAddress[0].InnerText.Trim());
                                }

                                string addressLocality = "";
                                HtmlNodeCollection CollectionaddressLocality = MainCollection[j].SelectNodes(".//span[@itemprop='addressLocality']");
                                if (CollectionaddressLocality != null)
                                {
                                    addressLocality = CollectionaddressLocality[0].InnerText.Trim();
                                }
                                string addressRegion = "";
                                HtmlNodeCollection CollectionaddressRegion = MainCollection[j].SelectNodes(".//span[@itemprop='addressRegion']");
                                if (CollectionaddressRegion != null)
                                {
                                    addressRegion = CollectionaddressRegion[0].InnerText.Trim();
                                }
                                string postalCode = "";
                                HtmlNodeCollection CollectionpostalCode = MainCollection[j].SelectNodes(".//span[@itemprop='postalCode']");
                                if (CollectionpostalCode != null)
                                {
                                    postalCode = CollectionpostalCode[0].InnerText.Trim();
                                }
                                string telephone = "";
                                HtmlNodeCollection Collectiontelephone = MainCollection[j].SelectNodes(".//b[@itemprop='telephone']");
                                if (Collectiontelephone != null)
                                {
                                    telephone = Collectiontelephone[0].InnerText.Trim().Replace("&nbsp;", "");
                                }
                                string resultTrucks = "";
                                string DefaultTrucks = MainCollection[j].InnerText;
                                int startTrucks = DefaultTrucks.IndexOf("Trucks:") + 7;
                                int endTrucks = DefaultTrucks.IndexOf("Drivers:", startTrucks);
                                if (startTrucks != 6 || endTrucks != -1)
                                {
                                    resultTrucks = DefaultTrucks.Substring(startTrucks, endTrucks - startTrucks).Trim().Replace("\t\t", "");
                                }
                                string resultDrivers = "";
                                string DefaultDriverss = MainCollection[j].InnerText;
                                int startDriverss = DefaultDriverss.IndexOf("Drivers:") + 8;
                                int endDriverss = DefaultDriverss.IndexOf("\n\t\t\t\tUSDOT", startDriverss);
                                if (startTrucks != 7 || endTrucks != -1)
                                {
                                    resultDrivers = DefaultDriverss.Substring(startDriverss, endDriverss - startDriverss).Trim().Replace("\t\t", "");
                                }
                                string resultUSDOT = "";
                                string DefaultUSDOT = MainCollection[j].InnerText;
                                int startUSDOT = DefaultUSDOT.IndexOf("USDOT") + 5;
                                int endUSDOT = startUSDOT + 17;
                                if (startTrucks != 4 || endTrucks != 21)
                                {
                                    resultUSDOT = DefaultUSDOT.Substring(startUSDOT, endUSDOT - startUSDOT).Trim().Replace("\t\t", "");
                                    resultUSDOT = resultUSDOT.Replace("&nbsp;", "");
                                    resultUSDOT = Regex.Match(resultUSDOT, @"\d+").Value;
                                }
                                File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", resultUSDOT + "," + Title + "," + NameCom + "," + streetAddress + "," + addressLocality + "," + addressRegion + "," + postalCode + "," + resultTrucks + "," + resultDrivers + "," + telephone + "," + Environment.NewLine);
                            }
                            catch (Exception ex)
                            {
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public static string Replace1(string MainString)
        {
            MainString = MainString.Replace("\n", " ");
            MainString = MainString.Replace("&nbsp;", " ");
            MainString = MainString.Replace("\t", "");
            MainString = MainString.Replace("\r", "");
            MainString = MainString.Replace("   ", " ");
            MainString = MainString.Replace(",", " ");
            return MainString;
        }

        public static string phonevalidator()
        {
            string responseData = string.Empty;
            try
            {
                string[] Hastags = System.IO.File.ReadAllLines(@"C:\Tunis\BackUp\IMDBPages\hastag.txt");
                Thread[] ts = new Thread[Hastags.Count()];
                foreach (string item in Hastags)
                {
                    MusicEvent _MusicEvent = new MusicEvent();
                    if (item == "")
                    {
                        _MusicEvent.PhoneLineType = "";
                        _MusicEvent.PhoneLocation = "";
                        _MusicEvent.PhoneCompany = "";
                        _MusicEvent.Phone = item;
                        _MusicEventList.Add(_MusicEvent);
                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", _MusicEvent.PhoneLineType + "," + _MusicEvent.PhoneLocation + "," + _MusicEvent.PhoneCompany + "," + _MusicEvent.Phone + Environment.NewLine);
                        continue;
                    }
                    try
                    {
                        CookieContainer cookies = new CookieContainer();
                        responseData = GetFirstRespParams("https://www.phonevalidator.com", ref cookies);
                        string stringUrl2 = "https://www.phonevalidator.com/index.aspx";
                        string __VIEWSTATE = ExtractViewState(responseData, "__VIEWSTATE");
                        string __VIEWSTATEGENERATOR = ExtractViewState(responseData, "__VIEWSTATEGENERATOR");
                        string __EVENTVALIDATION = ExtractViewState(responseData, "__EVENTVALIDATION");
                        string postData = "__EVENTTARGET=&__EVENTARGUMENT=" +
                            "&__VIEWSTATE=" + __VIEWSTATE +
                            "&__VIEWSTATEGENERATOR=" + __VIEWSTATEGENERATOR +
                            "&__EVENTVALIDATION=" + __EVENTVALIDATION +
                            "&ctl00%24ContentPlaceHolder1%24txtPhone==" + item +
                            "&ctl00%24ContentPlaceHolder1%24SearchButton=Search";
                        string HostName = "www.phonevalidator.com";
                        responseData = GetDataWithParams(stringUrl2, ref cookies, postData, HostName);
                        responseData = GetFirstRespParams("https://www.phonevalidator.com/results.aspx", ref cookies);

                        HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
                        htmlDocument.LoadHtml(responseData);
                        HtmlNodeCollection tr = htmlDocument.DocumentNode.SelectNodes("//div[@id='ContentPlaceHolder1_ResultsPanel']/div/ul/li/span");

                        if (tr == null)
                        {
                            _MusicEvent.PhoneLineType = "";
                            _MusicEvent.PhoneLocation = "";
                            _MusicEvent.PhoneCompany = "";
                            _MusicEvent.Phone = item;
                            _MusicEventList.Add(_MusicEvent);
                            File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", _MusicEvent.PhoneLineType + "," + _MusicEvent.PhoneLocation + "," + _MusicEvent.PhoneCompany + "," + _MusicEvent.Phone + Environment.NewLine);
                            continue;
                        }

                        if (tr.Count() == 6)
                        {

                            _MusicEvent.PhoneLineType = tr[2].InnerText;
                            _MusicEvent.PhoneLocation = tr[3].InnerText;
                            _MusicEvent.PhoneCompany = tr[4].InnerText;
                            _MusicEvent.Phone = item;
                        }
                        else
                        {
                            _MusicEvent.PhoneLineType = "";
                            _MusicEvent.PhoneLocation = "";
                            _MusicEvent.PhoneCompany = "";
                            _MusicEvent.Phone = item;
                        }
                        _MusicEventList.Add(_MusicEvent);
                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", _MusicEvent.PhoneLineType + "," + _MusicEvent.PhoneLocation + "," + _MusicEvent.PhoneCompany + "," + _MusicEvent.Phone + Environment.NewLine);
                    }
                    catch (Exception ex)
                    {
                        _MusicEvent.PhoneLineType = "Error";
                        _MusicEvent.PhoneLocation = "Error";
                        _MusicEvent.PhoneCompany = "Error";
                        _MusicEvent.Phone = item;
                        _MusicEventList.Add(_MusicEvent);
                        File.AppendAllText(@"C:\Tunis\BackUp\IMDBPages\1.txt", _MusicEvent.PhoneLineType + "," + _MusicEvent.PhoneLocation + "," + _MusicEvent.PhoneCompany + "," + _MusicEvent.Phone + Environment.NewLine);
                        continue;
                    }
                }

                string appPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\ExportFile";
                bool exists = System.IO.Directory.Exists(appPath);
                if (!exists)
                {
                    System.IO.Directory.CreateDirectory(appPath);
                }
                string filePath = appPath + @"\google_search_" + DateTime.Now.ToString("MM-dd-yyyy-HHmmssfff") + ".csv";
                //dt = ToDataTable(_MusicEventList);
                ToCSV(dt, filePath);
            }
            catch (Exception ex)
            { }
            return responseData;
        }

        public static bool AcceptAll(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        public static string GetFirstRespParams(string URL, ref CookieContainer cookies)
        {
            //Access the page to extract view state information
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
            HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
            webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
            webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.CookieContainer = cookies;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            response.Cookies = webRequest.CookieContainer.GetCookies(webRequest.RequestUri);
            string responseData = responseReader.ReadToEnd();
            responseReader.Close();
            webRequest.KeepAlive = false;
            return responseData;

        }
        public static string GetFirst(string URL, ref CookieContainer cookies)
        {
            //Access the page to extract view state information
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
            HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
            webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
            webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.CookieContainer = cookies;
            webRequest.AllowAutoRedirect = false;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            string location = "";
            using (HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse())
            {
                location = response.GetResponseHeader("Location");
            }
            return location;

        }
        public static string GetDataWithParamsJson(string URL, ref CookieContainer cookies, string postData, string HostName)
        {
            //again access the login page with posted data to get cookies
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
            HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
            webRequest.Method = "POST";
            webRequest.Accept = "application/json, text/javascript, */*; q=0.01";
            webRequest.Headers.Add("Accept-Language", "en-US,en;q=0.9");
            webRequest.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
            webRequest.Headers.Add("X-Requested-With", "XMLHttpRequest");
            webRequest.CookieContainer = cookies;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";
            StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream());
            requestWriter.Write(postData.ToString());
            requestWriter.Close();
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            string responseData = responseReader.ReadToEnd();
            responseReader.Close();
            webRequest.KeepAlive = false;
            return responseData;
        }
        public static string GetDataWithParams(string URL, ref CookieContainer cookies, string postData, string HostName)
        {
            //again access the login page with posted data to get cookies
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
            HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
            webRequest.Method = "POST";
            webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
            webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.CookieContainer = cookies;
            webRequest.Host = HostName;
            webRequest.Proxy = new WebProxy();
            webRequest.KeepAlive = true;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";

            //access the page with posted data
            StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream());
            requestWriter.Write(postData);
            requestWriter.Close();
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            string responseData = responseReader.ReadToEnd();
            responseReader.Close();
            webRequest.KeepAlive = false;
            return responseData;
        }
        private static string ExtractViewState(string s, string Name)
        {
            string viewStateNameDelimiter = Name;
            string valueDelimiter = "value=\"";

            int viewStateNamePosition = s.IndexOf(viewStateNameDelimiter);
            int viewStateValuePosition = s.IndexOf(valueDelimiter, viewStateNamePosition);

            int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
            int viewStateEndPosition = s.IndexOf("\"", viewStateStartPosition);

            return HttpUtility.UrlEncodeUnicode(s.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition));
        }

        public static string Replace(string MainString)
        {
            MainString = MainString.Replace("\n", " ");
            MainString = MainString.Replace("(", "%28");
            MainString = MainString.Replace(")", "%29");
            MainString = MainString.Replace("\t", "");
            MainString = MainString.Replace("\r", "");
            MainString = MainString.Replace("   ", " ");
            MainString = MainString.Replace(",", " ");
            MainString = MainString.Replace("*", " ");
            MainString = MainString.Replace("&amp;", "&");
            MainString = MainString.Replace("&nbsp;", "");
            return MainString;
        }      

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // writeLog("Start Scraping *****");
            // number = 0;
            // dt = new DataTable();
            //// metroGrid1.DataSource = dt;
            // // metroButton2.Enabled = false;
            // if (txtFirstName.Text != "")
            // {
            //     //metroProgressSpinner2.Visible = true;
            //   //  metroProgressSpinner1.Visible = true;
            //     userDetails();
            // }
            // else
            // {
            //     // metroButton2.Enabled = true;
            //     MessageBox.Show("Please browse and select correct text file");
            // }
        }

        //public static void GetTableValues()
        //{
        //    try
        //    {
        //        string responseData = string.Empty;
        //        CookieContainer cookies = new CookieContainer();
        //        responseData = GetFirstRespParams("https://commerce.health.state.ny.us/hcs/index.html", ref cookies);
        //        //User login from below request
        //         string postData = "userid=aw433258&password=kehilla45&Action=none";
        //         string HostName = "commerce.health.state.ny.us";
        //         responseData = GetDataWithParams("https://commerce.health.state.ny.us/loginpost.html", ref cookies, postData, HostName);

        //         string url = GetURL("https://nysiis.health.state.ny.us/",  cookies);
        //       //  url = GetURL(url, cookies);
        //         responseData = GetFirstRespParams(url.Replace("commerce", "nysiis"), ref cookies);
        //         string HomeTypeHtml = responseData;
        //         int start = HomeTypeHtml.IndexOf("search_ui.findStudentForSchool?pSecureId=") + 41;
        //         int end = HomeTypeHtml.IndexOf("\" target=\"_parent\" style");
        //         string result = HomeTypeHtml.Substring(start, end - start);
        //         responseData = GetFirstRespParams("https://nysiis.health.state.ny.us/PRD/search_ui.findStudentForSchool?pSecureId=" + result, ref cookies);
        //          HomeTypeHtml = responseData;
        //          start = HomeTypeHtml.IndexOf("name=\"txtOrgId\" value=\"") + 24;
        //          end = HomeTypeHtml.IndexOf("<input type=\"hidden\" name=\"hAction\"");
        //         string result1 = HomeTypeHtml.Substring(start, end - start-3);

        //         postData = "fldSecurid=" + result + "&fldpTarget=4&txtOrgId=" + result1 + "&hAction=&txtLastName=Beck&optSexCode=&cmdFindClient=Find&txtFirstName=Chaim&txtareacode=&txtphone1=&txtphone2=&txtMiddleName=&txtBirthDate=08%2F08%2F2013&txtMaidenLast=&txtWirID=&txtMothersFirst=";

        //         responseData = GetDataWithParams("https://nysiis.health.state.ny.us/PRD/!search_ui.matchClient", ref cookies, postData, HostName);
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
        //    }
        //}
        //public static bool AcceptAll(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        //{
        //    return true;
        //}
        //public static string GetURL(string URL, CookieContainer cookies)
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
        //    //Access the page to extract view state information
        //    HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
        //    webRequest.Method = "POST";
        //    webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        //    webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
        //    webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        //    webRequest.ContentType = "application/x-www-form-urlencoded";
        //    webRequest.CookieContainer = cookies;
        //    webRequest.Host = "commerce.health.state.ny.us";
        //    webRequest.Proxy = new WebProxy();
        //    webRequest.KeepAlive = false;
        //    webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
        //    StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
        //    HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
        //    response.Cookies = webRequest.CookieContainer.GetCookies(webRequest.RequestUri);
        //    string responseData = responseReader.ReadToEnd();
        //    responseReader.Close();
        //    return response.ResponseUri.ToString();
        //}
        //public static string GetFirstRespParams(string URL, ref CookieContainer cookies)
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
        //    //Access the page to extract view state information
        //    HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
        //    webRequest.Method = "POST";
        //    webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        //    webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
        //    webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        //    webRequest.ContentType = "application/x-www-form-urlencoded";
        //    webRequest.CookieContainer = cookies;
        // //   webRequest.Host = "commerce.health.state.ny.us";
        //    webRequest.Proxy = new WebProxy();
        //    webRequest.KeepAlive = false;
        //    webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
        //    StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
        //    HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
        //    response.Cookies = webRequest.CookieContainer.GetCookies(webRequest.RequestUri);
        //    string responseData = responseReader.ReadToEnd();
        //    responseReader.Close();
        //    return responseData;
        //}
        //public static string GetDataWithParams(string URL, ref CookieContainer cookies, string postData, string HostName)
        //{
        //    try
        //    {
        //        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //        ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
        //        HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
        //        webRequest.Method = "POST";
        //        webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        //        webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
        //        webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        //        webRequest.ContentType = "application/x-www-form-urlencoded";
        //        webRequest.CookieContainer = cookies;
        //        webRequest.Host = HostName;
        //        webRequest.Proxy = new WebProxy();
        //        webRequest.KeepAlive = false;
        //        webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
        //        //access the page with posted data
        //        StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream());
        //        requestWriter.Write(postData);
        //        requestWriter.Close();
        //        StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
        //        string responseData = responseReader.ReadToEnd();
        //        responseReader.Close();
        //        webRequest.KeepAlive = false;
        //        return responseData;
        //    }
        //    catch (Exception)
        //    {
        //        return "";
        //    }
        //}

        //public async Task userDetails()
        //{
        //    try
        //    {
        //        await Task.Run(() =>
        //                   {
        //                       ThreadCall();
        //                   });
        //      //  await excel();
        //       // metroTextBox2.Text = "";
        //       // metroButton2.Enabled = true;
        //       // metroProgressSpinner2.Visible = false;
        //       // metroProgressSpinner1.Visible = false;
        //    }
        //    catch (Exception ex)    
        //    {
        //       // metroProgressSpinner2.Visible = false;
        //       // metroProgressSpinner1.Visible = false;
        //       // metroButton2.Enabled = true;
        //        MessageBox.Show("Error" + ex.ToString());
        //    }
        //}
        //public async Task excel()
        //{
        //    if (emailsAll.Count() < 32)
        //    {
        //        writeLog("Start Export To CSV");
        //        try
        //        {
        //            string appPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\ExportFile";
        //            bool exists = System.IO.Directory.Exists(appPath);
        //            if (!exists)
        //            {
        //                System.IO.Directory.CreateDirectory(appPath);
        //            }
        //            string filePath = appPath + @"\google_search_" + DateTime.Now.ToString("MM-dd-yyyy-HHmmssfff") + ".csv";
        //            dt = ToDataTable(_MusicEventList);
        //            ToCSV(dt, filePath);
        //           // metroGrid1.DataSource = dt;
        //            _MusicEventList = new List<MusicEvent>();
        //            MetroMessageBox.Show(this, "File Path :" + filePath, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            Process proc = new Process();
        //            proc.StartInfo = new ProcessStartInfo("excel.exe", filePath);
        //            proc.Start();
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("Error" + ex.ToString());
        //        }
        //    }
        //}
        //public async void ThreadCall()
        //{
        //    try
        //    {
        //        GoogleSearch();
        //    }
        //    catch (Exception)
        //    {

        //    }
        //}

        //public static string GetFirstRespParams1(string URL, ref CookieContainer cookies)
        //{
        //    //Access the page to extract view state information
        //    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
        //    HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
        //    webRequest.CookieContainer = cookies;
        //    StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
        //    HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
        //    response.Cookies = webRequest.CookieContainer.GetCookies(webRequest.RequestUri);
        //    string responseData = responseReader.ReadToEnd();
        //    responseReader.Close();
        //    webRequest.KeepAlive = false;
        //    return responseData;
        //}
        //public static string GetDataWithParams1(string URL, ref CookieContainer cookies, string postData, string HostName)
        //{
        //    //again access the login page with posted data to get cookies
        //    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAll);
        //    HttpWebRequest webRequest = WebRequest.Create(URL) as HttpWebRequest;
        //    webRequest.Method = "POST";
        //    webRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        //    webRequest.Headers.Add("Accept-Language", "en-us;q=0.7,en;q=0.3");
        //    webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        //    webRequest.ContentType = "application/x-www-form-urlencoded";
        //    webRequest.CookieContainer = cookies;
        //    webRequest.Host = HostName;
        //    webRequest.Proxy = new WebProxy();
        //    webRequest.KeepAlive = true;
        //    webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";

        //    //access the page with posted data
        //    StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream());
        //    requestWriter.Write(postData);
        //    requestWriter.Close();
        //    StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
        //    string responseData = responseReader.ReadToEnd();
        //    responseReader.Close();
        //    webRequest.KeepAlive = false;
        //    return responseData;
        //}
        //private static string ExtractViewState1(string s, string Name)
        //{
        //    string viewStateNameDelimiter = Name;
        //    string valueDelimiter = "value=\"";

        //    int viewStateNamePosition = s.IndexOf(viewStateNameDelimiter);
        //    int viewStateValuePosition = s.IndexOf(valueDelimiter, viewStateNamePosition);

        //    int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
        //    int viewStateEndPosition = s.IndexOf("\"", viewStateStartPosition);

        //    return HttpUtility.UrlEncodeUnicode(s.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition));
        //}

        ////public void GoogleSearch()
        ////{
        ////    try
        ////    {

        ////        string responseData = string.Empty;
        ////        CookieContainer cookies = new CookieContainer();
        ////        responseData = GetFirstRespParams("https://commerce.health.state.ny.us/hcs/index.html", ref cookies);
        ////        //User login from below request
        ////        string postData = "userid=aw433258&password=kehilla45&Action=none";
        ////        string HostName = "commerce.health.state.ny.us";
        ////        responseData = GetDataWithParams("https://commerce.health.state.ny.us/loginpost.html", ref cookies, postData, HostName);

        ////        string url = GetURL("https://nysiis.health.state.ny.us/", cookies);
        ////        //  url = GetURL(url, cookies);
        ////        responseData = GetFirstRespParams(url.Replace("commerce", "nysiis"), ref cookies);
        ////        string HomeTypeHtml = responseData;
        ////        int start = HomeTypeHtml.IndexOf("search_ui.findStudentForSchool?pSecureId=") + 41;
        ////        int end = HomeTypeHtml.IndexOf("\" target=\"_parent\" style");
        ////        string result = HomeTypeHtml.Substring(start, end - start);
        ////        responseData = GetFirstRespParams("https://nysiis.health.state.ny.us/PRD/search_ui.findStudentForSchool?pSecureId=" + result, ref cookies);
        ////        HomeTypeHtml = responseData;
        ////        start = HomeTypeHtml.IndexOf("name=\"txtOrgId\" value=\"") + 24;
        ////        end = HomeTypeHtml.IndexOf("<input type=\"hidden\" name=\"hAction\"");
        ////        string result1 = HomeTypeHtml.Substring(start, end - start - 3);

        ////        postData = "fldSecurid=" + result + "&fldpTarget=4&txtOrgId=" + result1 + "&hAction=&txtLastName=" + txtLastName.Text + "&optSexCode=&cmdFindClient=Find&txtFirstName=" + txtFirstName.Text +
        ////        "&txtareacode=&txtphone1=&txtphone2=&txtMiddleName=&txtBirthDate=";
        ////        if (metroDateTime1.Value.Date.Year != 1753)
        ////        {
        ////            postData = postData + metroDateTime1.Value.Date.Month + "%2F" + metroDateTime1.Value.Date.Day + "%2F" + metroDateTime1.Value.Date.Year;
        ////        }
        ////        postData = postData +"&txtMaidenLast=&txtWirID=&txtMothersFirst=";
        ////        responseData = GetDataWithParams("https://nysiis.health.state.ny.us/PRD/!search_ui.matchClient", ref cookies, postData, HostName);

        ////        start = responseData.IndexOf("<body") ;
        ////        end = responseData.IndexOf("</body>") + 7;
        ////         result = responseData.Substring(start, end - start);

        ////         updateContent(webBrowser1, result);

        ////    }
        ////    catch (Exception ex)
        ////    {

        ////    }
        ////}
        //void updateContent(WebBrowser textBox, string content)
        //{

        //    webBrowser1.Invoke(
        //        new EventHandler(
        //            delegate
        //            {
        //                textBox.DocumentText = content;
        //            }));
        //}


        //public static void ToCSV(DataTable dtDataTable, string strFilePath)
        //{
        //    StreamWriter sw = new StreamWriter(strFilePath, false);
        //    //headers  
        //    for (int i = 0; i < dtDataTable.Columns.Count; i++)
        //    {
        //        sw.Write(dtDataTable.Columns[i]);
        //        if (i < dtDataTable.Columns.Count - 1)
        //        {
        //            sw.Write(",");
        //        }
        //    }
        //    sw.Write(sw.NewLine);
        //    foreach (DataRow dr in dtDataTable.Rows)
        //    {
        //        for (int i = 0; i < dtDataTable.Columns.Count; i++)
        //        {
        //            if (!Convert.IsDBNull(dr[i]))
        //            {
        //                string value = dr[i].ToString();
        //                if (i == 6)
        //                {
        //                    value = "=\"" + value + "\"";
        //                }
        //                if (value.Contains(','))
        //                {
        //                    value = String.Format("\"{0}\"", value);
        //                    sw.Write(value);
        //                }
        //                else
        //                {
        //                    sw.Write(value);
        //                }
        //            }
        //            if (i < dtDataTable.Columns.Count - 1)
        //            {
        //                sw.Write(",");
        //            }
        //        }
        //        sw.Write(sw.NewLine);
        //    }
        //    sw.Close();
        //}
        //public static DataTable ToDataTable<T>(List<T> items)
        //{
        //    DataTable dataTable = new DataTable(typeof(T).Name);
        //    //Get all the properties
        //    PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        //    foreach (PropertyInfo prop in Props)
        //    {
        //        //Setting column names as Property names
        //        dataTable.Columns.Add(prop.Name);
        //    }
        //    foreach (T item in items)
        //    {
        //        var values = new object[Props.Length];
        //        for (int i = 0; i < Props.Length; i++)
        //        {
        //            //inserting property values to datatable rows
        //            values[i] = Props[i].GetValue(item, null);
        //        }
        //        dataTable.Rows.Add(values);
        //    }
        //    //put a breakpoint here and check datatable
        //    return dataTable;
        //}

        //public static void writeLog(string content)
        //{
        //    try
        //    {
        //        string logfilePath = AppDomain.CurrentDomain.BaseDirectory + "Logs\\" + DateTime.Now.ToString("ddMMMyyyy") + ".log";
        //        Directory.CreateDirectory(Path.GetDirectoryName(logfilePath));
        //        FileStream fs = new FileStream(logfilePath, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite);
        //        StreamWriter sw = new StreamWriter(fs);
        //        sw.BaseStream.Seek(0, SeekOrigin.End);
        //        sw.WriteLine(": " + content);
        //        sw.Flush();
        //        sw.Close();
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}


        private void metroTabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
    public class MusicEvent
    {
        public string Phone { get; set; }

        public string PhoneLineType { get; set; }
        public string PhoneLocation { get; set; }

        public string PhoneCompany { get; set; }

    }
    public class Item
    {
        public object idOPEN { get; set; }
        public string name { get; set; }
        public string nameSEO { get; set; }
        public string logo { get; set; }
        public string logoSm { get; set; }
        public string titleCount { get; set; }
        public object title { get; set; }
        public object country { get; set; }
        public object titles { get; set; }
        public object totals { get; set; }
        public object member { get; set; }
        public bool isLoggedIn { get; set; }
        public bool rtnBool { get; set; }
        public object rtnString { get; set; }
        public DateTime rtnDate { get; set; }
        public object rtnENC { get; set; }
        public int rtnInt { get; set; }
        public int rtnRows { get; set; }
        public object rtnIDENC { get; set; }
        public object letters { get; set; }
        public string searchType { get; set; }
        public string id { get; set; }
        public string idENC { get; set; }
        public object uid { get; set; }
        public object sec { get; set; }
    }

    public class RootObject
    {
        public List<Item> items { get; set; }
        public List<object> error { get; set; }
        public bool refresh { get; set; }
        public int page { get; set; }
        public int pages { get; set; }
        public int perPage { get; set; }
        public int total { get; set; }
        public string status { get; set; }
        public int code { get; set; }
        public int loggedin { get; set; }
    }

    public class Amazon
    {
        public string ASIN { get; set; }
        public DateTime DateofReview { get; set; }
        public string SellerID { get; set; }
        public string ReviwerID { get; set; }
        public double ReviewRating { get; set; }
        public string RatingSummary { get; set; }
        public string TextoftheReview { get; set; }
        public bool Photo { get; set; }
        public bool Video { get; set; }

    }
    public class CoverScans
    {
        public string lrgScan { get; set; }
        public string medScan { get; set; }
        public string thmScan { get; set; }
        public object location { get; set; }
        public object member { get; set; }
        public object title { get; set; }
        public bool isMissing { get; set; }
        public bool isAdult { get; set; }
        public bool isLoggedIn { get; set; }
        public bool rtnBool { get; set; }
        public object rtnString { get; set; }
        public DateTime rtnDate { get; set; }
        public object rtnENC { get; set; }
        public int rtnInt { get; set; }
        public int rtnRows { get; set; }
        public object rtnIDENC { get; set; }
        public object letters { get; set; }
        public object searchType { get; set; }
        public object id { get; set; }
        public object idENC { get; set; }
        public object uid { get; set; }
        public object sec { get; set; }
    }

    public class Item2
    {
        public object idOPEN { get; set; }
        public string name { get; set; }
        public string nameSEO { get; set; }
        public string type { get; set; }
        public string volume { get; set; }
        public string years { get; set; }
        public object activeYears { get; set; }
        public object comment { get; set; }
        public object publisher { get; set; }
        public object issues { get; set; }
        public object types { get; set; }
        public object issue { get; set; }
        public CoverScans coverScans { get; set; }
        public object generes { get; set; }
        public object totals { get; set; }
        public string searches { get; set; }
        public object member { get; set; }
        public bool isAdult { get; set; }
        public object altSearch { get; set; }
        public bool isLoggedIn { get; set; }
        public bool rtnBool { get; set; }
        public object rtnString { get; set; }
        public DateTime rtnDate { get; set; }
        public object rtnENC { get; set; }
        public int rtnInt { get; set; }
        public int rtnRows { get; set; }
        public object rtnIDENC { get; set; }
        public List<string> letters { get; set; }
        public string searchType { get; set; }
        public string id { get; set; }
        public string idENC { get; set; }
        public object uid { get; set; }
        public object sec { get; set; }
    }

    public class RootObject2
    {
        public List<Item> items { get; set; }
        public List<object> error { get; set; }
        public bool refresh { get; set; }
        public int page { get; set; }
        public int pages { get; set; }
        public int perPage { get; set; }
        public int total { get; set; }
        public string status { get; set; }
        public int code { get; set; }
        public int loggedin { get; set; }
    }
    public class ComicBook
    {
        public string URLofpageImage { get; set; }
        public string URLofpage { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public string PublishPeriod { get; set; }
        public string Volume { get; set; }
        public string ComicAge { get; set; }
        public string PublishDate { get; set; }
        public string PublishDate2 { get; set; }
        public string CoverPrice { get; set; }
        public string StoryArc { get; set; }
        public string UPC { get; set; }
        public string ISBN10 { get; set; }
        public string ISBN13 { get; set; }
        public string CoverArt { get; set; }
        public string Artists { get; set; }
        public string Inkers { get; set; }
        public string Writers { get; set; }
        public string Letterers { get; set; }
        public string Colorists { get; set; }
        public string Editors { get; set; }
        public string Facts { get; set; }
        public string Stories1 { get; set; }
        public string Stories2 { get; set; }
        public string Stories3 { get; set; }
        public string Stories4 { get; set; }
        public string Stories5 { get; set; }
        public string Stories6 { get; set; }
        public string Stories7 { get; set; }
        public string Stories8 { get; set; }
        public string Stories9 { get; set; }
        public string Stories10 { get; set; }
        public string Stories11 { get; set; }
        public string Stories12 { get; set; }
        public string Stories13 { get; set; }
        public string Stories14 { get; set; }
        public string Stories15 { get; set; }
    }
    public class EdgeFollowedBy
    {
        public int count { get; set; }
    }

    public class EdgeFollow
    {
        public int count { get; set; }
    }

    public class EdgeMutualFollowedBy
    {
        public int count { get; set; }
        public List<object> edges { get; set; }
    }

    public class PageInfo
    {
        public bool has_next_page { get; set; }
        public object end_cursor { get; set; }
    }

    public class EdgeFelixVideoTimeline
    {
        public int count { get; set; }
        public PageInfo page_info { get; set; }
        public List<object> edges { get; set; }
    }

    public class PageInfo2
    {
        public bool has_next_page { get; set; }
        public object end_cursor { get; set; }
    }

    public class Node2
    {
        public string text { get; set; }
    }

    public class Edge2
    {
        public Node2 node { get; set; }
    }

    public class EdgeMediaToCaption
    {
        public List<Edge2> edges { get; set; }
    }

    public class EdgeMediaToComment
    {
        public int count { get; set; }
    }

    public class Dimensions
    {
        public int height { get; set; }
        public int width { get; set; }
    }

    public class EdgeLikedBy
    {
        public int count { get; set; }
    }

    public class EdgeMediaPreviewLike
    {
        public int count { get; set; }
    }

    public class Owner
    {
        public string id { get; set; }
        public string username { get; set; }
    }

    public class ThumbnailResource
    {
        public string src { get; set; }
        public int config_width { get; set; }
        public int config_height { get; set; }
    }

    public class Node
    {
        public string __typename { get; set; }
        public string id { get; set; }
        public EdgeMediaToCaption edge_media_to_caption { get; set; }
        public string shortcode { get; set; }
        public EdgeMediaToComment edge_media_to_comment { get; set; }
        public bool comments_disabled { get; set; }
        public int taken_at_timestamp { get; set; }
        public Dimensions dimensions { get; set; }
        public string display_url { get; set; }
        public EdgeLikedBy edge_liked_by { get; set; }
        public EdgeMediaPreviewLike edge_media_preview_like { get; set; }
        public object location { get; set; }
        public object gating_info { get; set; }
        public object fact_check_overall_rating { get; set; }
        public object fact_check_information { get; set; }
        public string media_preview { get; set; }
        public Owner owner { get; set; }
        public string thumbnail_src { get; set; }
        public List<ThumbnailResource> thumbnail_resources { get; set; }
        public bool is_video { get; set; }
        public string accessibility_caption { get; set; }
    }

    public class Edge
    {
        public Node node { get; set; }
    }

    public class EdgeOwnerToTimelineMedia
    {
        public int count { get; set; }
        public PageInfo2 page_info { get; set; }
        public List<Edge> edges { get; set; }
    }

    public class PageInfo3
    {
        public bool has_next_page { get; set; }
        public object end_cursor { get; set; }
    }

    public class EdgeSavedMedia
    {
        public int count { get; set; }
        public PageInfo3 page_info { get; set; }
        public List<object> edges { get; set; }
    }

    public class PageInfo4
    {
        public bool has_next_page { get; set; }
        public object end_cursor { get; set; }
    }

    public class EdgeMediaCollections
    {
        public int count { get; set; }
        public PageInfo4 page_info { get; set; }
        public List<object> edges { get; set; }
    }

    public class User
    {
        public string biography { get; set; }
        public bool blocked_by_viewer { get; set; }
        public bool country_block { get; set; }
        public string external_url { get; set; }
        public string external_url_linkshimmed { get; set; }
        public EdgeFollowedBy edge_followed_by { get; set; }
        public bool followed_by_viewer { get; set; }
        public EdgeFollow edge_follow { get; set; }
        public bool follows_viewer { get; set; }
        public string full_name { get; set; }
        public bool has_channel { get; set; }
        public bool has_blocked_viewer { get; set; }
        public int highlight_reel_count { get; set; }
        public bool has_requested_viewer { get; set; }
        public string id { get; set; }
        public bool is_business_account { get; set; }
        public bool is_joined_recently { get; set; }
        public string business_category_name { get; set; }
        public bool is_private { get; set; }
        public bool is_verified { get; set; }
        public EdgeMutualFollowedBy edge_mutual_followed_by { get; set; }
        public string profile_pic_url { get; set; }
        public string profile_pic_url_hd { get; set; }
        public bool requested_by_viewer { get; set; }
        public string username { get; set; }
        public object connected_fb_page { get; set; }
        public EdgeFelixVideoTimeline edge_felix_video_timeline { get; set; }
        public EdgeOwnerToTimelineMedia edge_owner_to_timeline_media { get; set; }
        public EdgeSavedMedia edge_saved_media { get; set; }
        public EdgeMediaCollections edge_media_collections { get; set; }
    }

    public class Graphql
    {
        public User user { get; set; }
    }

    public class RootObject22
    {
        public string logging_page_id { get; set; }
        public bool show_suggested_profiles { get; set; }
        public bool show_follow_dialog { get; set; }
        public Graphql graphql { get; set; }
        public object toast_content_on_load { get; set; }
    }
}

public class WebClientEx : WebClient
{
    public CookieContainer CookieContainer { get; private set; }

    public WebClientEx()
    {
        CookieContainer = new CookieContainer();
    }

    protected override WebRequest GetWebRequest(Uri address)
    {
        var request = base.GetWebRequest(address);
        if (request is HttpWebRequest)
        {
            (request as HttpWebRequest).CookieContainer = CookieContainer;
        }
        return request;
    }
}
public class CookieAwareWebClient : WebClient
{
    public CookieContainer CookieContainer { get; set; }
    public Uri Uri { get; set; }
    Uri _responseUri;
    public bool AllowRedirect = true;
    public Uri ResponseUri
    {
        get { return _responseUri; }
    }

    public CookieAwareWebClient()
        : this(new CookieContainer())
    {
    }

    public CookieAwareWebClient(CookieContainer cookies)
    {
        this.CookieContainer = cookies;
    }

    protected override WebRequest GetWebRequest(Uri address)
    {
        WebRequest request = base.GetWebRequest(address);


        if (request is HttpWebRequest)
        {

            (request as HttpWebRequest).CookieContainer = this.CookieContainer;

        }

        HttpWebRequest httpRequest = (HttpWebRequest)request;

        httpRequest.AllowAutoRedirect = AllowRedirect;

        httpRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        return httpRequest;
    }

    protected override WebResponse GetWebResponse(WebRequest request)
    {
        var response = (HttpWebResponse)base.GetWebResponse(request);

        String setCookieHeader = response.Headers[HttpResponseHeader.SetCookie];
        if (response.Headers["Location"] != null)
            _responseUri = new System.Uri(response.Headers["Location"]);
        if (setCookieHeader != null)
        {
            //do something if needed to parse out the cookie.
            if (setCookieHeader != null)
            {
                Cookie cookie = new Cookie(); //create cookie
                //this.CookieContainer.Add(cookie);
            }
        }
        return response;
    }

    public string GetCookiesAsString(Uri address)
    {
        string result = "";
        foreach (Cookie cookie in this.CookieContainer.GetCookies(address))
        {
            result += cookie.Name + "=" + cookie.Value + ";";
        }
        return result;

    }

}