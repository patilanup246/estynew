﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleSearch
{
    public class Comic
    {
        public class Age
        {
            public object idOPEN { get; set; }
            public string name { get; set; }
            public string nameSEO { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Dates
        {
            public int month { get; set; }
            public string monthName { get; set; }
            public string year { get; set; }
        }

        public class Value
        {
            public object now { get; set; }
            public string last { get; set; }
            public object paid { get; set; }
            public object gain { get; set; }
            public object upDn { get; set; }
            public object arrow { get; set; }
            public object issueCount { get; set; }
            public string dateChange { get; set; }
            public bool graded { get; set; }
            public object id { get; set; }
            public object idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Values
        {
            public string v100 { get; set; }
            public object v100Last { get; set; }
            public object v100UpDn { get; set; }
            public object v100Arrow { get; set; }
            public string v99 { get; set; }
            public object v99Last { get; set; }
            public object v99UpDn { get; set; }
            public object v99Arrow { get; set; }
            public string v98 { get; set; }
            public object v98Last { get; set; }
            public object v98UpDn { get; set; }
            public object v98Arrow { get; set; }
            public string v96 { get; set; }
            public object v96Last { get; set; }
            public object v96UpDn { get; set; }
            public object v96Arrow { get; set; }
            public string v94 { get; set; }
            public object v94Last { get; set; }
            public object v94UpDn { get; set; }
            public object v94Arrow { get; set; }
            public string v92 { get; set; }
            public object v92Last { get; set; }
            public object v92UpDn { get; set; }
            public object v92Arrow { get; set; }
            public string v90 { get; set; }
            public object v90Last { get; set; }
            public object v90UpDn { get; set; }
            public object v90Arrow { get; set; }
            public string v85 { get; set; }
            public object v85Last { get; set; }
            public object v85UpDn { get; set; }
            public object v85Arrow { get; set; }
            public string v80 { get; set; }
            public object v80Last { get; set; }
            public object v80UpDn { get; set; }
            public object v80Arrow { get; set; }
            public string v75 { get; set; }
            public object v75Last { get; set; }
            public object v75UpDn { get; set; }
            public object v75Arrow { get; set; }
            public string v70 { get; set; }
            public object v70Last { get; set; }
            public object v70UpDn { get; set; }
            public object v70Arrow { get; set; }
            public string v65 { get; set; }
            public object v65Last { get; set; }
            public object v65UpDn { get; set; }
            public object v65Arrow { get; set; }
            public string v60 { get; set; }
            public object v60Last { get; set; }
            public object v60UpDn { get; set; }
            public object v60Arrow { get; set; }
            public string v55 { get; set; }
            public object v55Last { get; set; }
            public object v55UpDn { get; set; }
            public object v55Arrow { get; set; }
            public string v50 { get; set; }
            public object v50Last { get; set; }
            public object v50UpDn { get; set; }
            public object v50Arrow { get; set; }
            public string v45 { get; set; }
            public object v45Last { get; set; }
            public object v45UpDn { get; set; }
            public object v45Arrow { get; set; }
            public string v40 { get; set; }
            public object v40Last { get; set; }
            public object v40UpDn { get; set; }
            public object v40Arrow { get; set; }
            public string v35 { get; set; }
            public object v35Last { get; set; }
            public object v35UpDn { get; set; }
            public object v35Arrow { get; set; }
            public string v30 { get; set; }
            public object v30Last { get; set; }
            public object v30UpDn { get; set; }
            public object v30Arrow { get; set; }
            public string v25 { get; set; }
            public object v25Last { get; set; }
            public object v25UpDn { get; set; }
            public object v25Arrow { get; set; }
            public string v20 { get; set; }
            public object v20Last { get; set; }
            public object v20UpDn { get; set; }
            public object v20Arrow { get; set; }
            public string v18 { get; set; }
            public object v18Last { get; set; }
            public object v18UpDn { get; set; }
            public object v18Arrow { get; set; }
            public string v15 { get; set; }
            public object v15Last { get; set; }
            public object v15UpDn { get; set; }
            public object v15Arrow { get; set; }
            public string v10 { get; set; }
            public object v10Last { get; set; }
            public object v10UpDn { get; set; }
            public object v10Arrow { get; set; }
            public string v05 { get; set; }
            public object v05Last { get; set; }
            public object v05UpDn { get; set; }
            public object v05Arrow { get; set; }
            public bool notValued { get; set; }
        }

        public class CoverScans
        {
            public string lrgScan { get; set; }
            public string medScan { get; set; }
            public string thmScan { get; set; }
            public object location { get; set; }
            public object member { get; set; }
            public object title { get; set; }
            public bool isMissing { get; set; }
            public bool isAdult { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public object id { get; set; }
            public object idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class ActiveYears
        {
            public string start { get; set; }
            public string end { get; set; }
        }

        public class Country
        {
            public object idOPEN { get; set; }
            public object order { get; set; }
            public string name { get; set; }
            public string nameSEO { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Publisher
        {
            public object idOPEN { get; set; }
            public string name { get; set; }
            public string nameSEO { get; set; }
            public object logo { get; set; }
            public object logoSm { get; set; }
            public object titleCount { get; set; }
            public object title { get; set; }
            public Country country { get; set; }
            public object titles { get; set; }
            public object totals { get; set; }
            public object member { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Title
        {
            public object idOPEN { get; set; }
            public string name { get; set; }
            public string nameSEO { get; set; }
            public string type { get; set; }
            public string volume { get; set; }
            public string years { get; set; }
            public ActiveYears activeYears { get; set; }
            public string comment { get; set; }
            public Publisher publisher { get; set; }
            public object issues { get; set; }
            public object types { get; set; }
            public object issue { get; set; }
            public object coverScans { get; set; }
            public object generes { get; set; }
            public object totals { get; set; }
            public string searches { get; set; }
            public object member { get; set; }
            public bool isAdult { get; set; }
            public string altSearch { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Member
        {
            public object idOPEN { get; set; }
            public object name { get; set; }
            public object nameSEO { get; set; }
            public object memberType { get; set; }
            public object memberTypeName { get; set; }
            public object memberInformation { get; set; }
            public object totals { get; set; }
            public object publishers { get; set; }
            public object lastOn { get; set; }
            public bool onlineNow { get; set; }
            public bool isDeleted { get; set; }
            public bool hasSubscription { get; set; }
            public bool isAdvisor { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Type
        {
            public object idOPEN { get; set; }
            public string name { get; set; }
            public string nameSEO { get; set; }
            public bool active { get; set; }
            public string abbrev { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public object rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public object searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class Item
        {
            public object issueId { get; set; }
            public object issueIdENC { get; set; }
            public object issueIdOPEN { get; set; }
            public object condition { get; set; }
            public object conditionName { get; set; }
            public bool autographed { get; set; }
            public object autographs { get; set; }
            public object paid { get; set; }
            public object issueInfo { get; set; }
            public bool forSale { get; set; }
            public bool inSalesQ { get; set; }
            public object memberScans { get; set; }
            public object saleItem { get; set; }
            public object box { get; set; }
            public object idOPEN { get; set; }
            public string number { get; set; }
            public string type { get; set; }
            public string dupChar { get; set; }
            public string typeDesc { get; set; }
            public string comments { get; set; }
            public bool graded { get; set; }
            public bool isAdult { get; set; }
            public bool key { get; set; }
            public object percentLevel { get; set; }
            public bool isWanted { get; set; }
            public string coverPrice { get; set; }
            public Age age { get; set; }
            public string issueCount { get; set; }
            public Dates dates { get; set; }
            public Value value { get; set; }
            public Values values { get; set; }
            public object gradedValues { get; set; }
            public object oldValues { get; set; }
            public object issueValue { get; set; }
            public CoverScans coverScans { get; set; }
            public object creator { get; set; }
            public object creators { get; set; }
            public object storyArcs { get; set; }
            public Title title { get; set; }
            public object searches { get; set; }
            public object upc { get; set; }
            public object isbn10 { get; set; }
            public object isbn13 { get; set; }
            public object extraInfo { get; set; }
            public object stories { get; set; }
            public Member member { get; set; }
            public List<Type> types { get; set; }
            public object watch { get; set; }
            public bool notValued { get; set; }
            public object owned { get; set; }
            public object dateViewed { get; set; }
            public bool isLoggedIn { get; set; }
            public bool rtnBool { get; set; }
            public string rtnString { get; set; }
            public DateTime rtnDate { get; set; }
            public object rtnENC { get; set; }
            public int rtnInt { get; set; }
            public int rtnRows { get; set; }
            public string rtnIDENC { get; set; }
            public object letters { get; set; }
            public string searchType { get; set; }
            public string id { get; set; }
            public string idENC { get; set; }
            public object uid { get; set; }
            public object sec { get; set; }
        }

        public class RootObject
        {
            public List<Item> items { get; set; }
            public int rtnRows { get; set; }
            public object rtnCount { get; set; }
            public int rtnInt { get; set; }
            public object rtnString { get; set; }
            public bool rtnBool { get; set; }
            public object rtnIDENC { get; set; }
            public object letters { get; set; }
            public List<object> error { get; set; }
            public bool refresh { get; set; }
            public int page { get; set; }
            public int pages { get; set; }
            public int perPage { get; set; }
            public int total { get; set; }
            public string status { get; set; }
            public int code { get; set; }
            public int loggedin { get; set; }
        }       
    }
}
